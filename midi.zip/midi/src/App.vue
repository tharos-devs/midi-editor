<template>
  <div id="app" class="midi-editor">
    <!-- Menu Bar -->
    <MenuBar />

    <!-- Tool Bar -->
    <ToolBar />

    <!-- Main Content Area -->
    <div class="main-content">
      <!-- Left Column: Track List -->
      <div class="left-column" :style="{ width: uiStore.trackListWidth + 'px' }">
        <TrackList />
      </div>

      <!-- Vertical Splitter -->
      <div
        class="vertical-splitter"
        @mousedown="startResizeTrackList"
      ></div>

      <!-- Right Column: Editor Area -->
      <div class="right-column">
        <!-- Timeline -->
        <div class="timeline-container">
          <div class="timeline-spacer" :style="{ width: uiStore.pianoKeysWidth + 'px' }"></div>
          <div class="timeline-scroll" ref="timelineScrollRef">
            <TimeLine />
          </div>
        </div>

        <!-- Piano + Grid Area -->
        <div class="piano-grid-container" ref="pianoGridContainerRef">
          <div class="piano-keys-container" ref="pianoKeysContainerRef">
            <PianoKeys />
          </div>

          <div class="piano-grid-scroll" ref="pianoGridScrollRef">
            <PianoGrid />
          </div>
        </div>

        <!-- Horizontal Splitter -->
        <div
          class="horizontal-splitter"
          @mousedown="startResizeMidiLanes"
        ></div>

        <!-- MIDI Lanes -->
        <div class="midi-lanes-container" :style="{ height: uiStore.midiLanesHeight + 'px' }">
          <div class="midi-lanes-spacer" :style="{ width: uiStore.pianoKeysWidth + 'px' }">
            <!-- Zone d'affichage de la vélocité pendant l'édition -->
            <div
              v-if="uiStore.velocityDisplay.visible"
              class="velocity-display"
            >
              {{ uiStore.velocityDisplay.value }}
            </div>

            <!-- Échelle de vélocité -->
            <div class="velocity-scale">
              <div
                v-for="level in velocityLevels"
                :key="level"
                class="velocity-scale-line"
                :class="{ 'max-velocity': level === 127 }"
                :style="velocityScaleLineStyle(level)"
              >
                <span class="velocity-scale-label">{{ level }}</span>
              </div>
            </div>
          </div>
          <div class="midi-lanes-scroll" ref="midiLanesScrollRef">
            <MidiLanes />
          </div>
        </div>
      </div>
    </div>

    <!-- Status Bar -->
    <StatusBar />
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue'
import { useUIStore } from './stores/ui'
import MenuBar from './components/MenuBar.vue'
import ToolBar from './components/ToolBar.vue'
import TrackList from './components/TrackList.vue'
import TimeLine from './components/TimeLine.vue'
import PianoKeys from './components/PianoKeys.vue'
import PianoGrid from './components/PianoGrid.vue'
import MidiLanes from './components/MidiLanes.vue'
import StatusBar from './components/StatusBar.vue'

const uiStore = useUIStore()

// Refs pour les éléments de scroll
const timelineScrollRef = ref(null)
const pianoGridScrollRef = ref(null)
const midiLanesScrollRef = ref(null)
const pianoGridContainerRef = ref(null)
const pianoKeysContainerRef = ref(null)

// Niveaux de vélocité à afficher sur l'échelle
const velocityLevels = [127, 96, 64, 32, 1]

// Variables pour le redimensionnement
let isResizingTrackList = false
let isResizingMidiLanes = false
let startX = 0
let startY = 0
let startWidth = 0
let startHeight = 0

// Fonction commune pour calculer la position d'une vélocité
// Cette fonction doit être identique à celle utilisée dans VelocityLane
const getVelocityPosition = (velocity) => {
  const maxVelocity = 127
  const minVelocity = 1
  // Calculer la position en pourcentage (127 en haut = 0%, 1 en bas = 100%)
  const percentage = (maxVelocity - velocity) / (maxVelocity - minVelocity)
  return percentage
}

const velocityScaleLineStyle = (level) => {
  // Hauteur des en-têtes d'onglets el-tabs (à ajuster selon votre CSS)
  const tabHeaderHeight = 40 // pixels

  if (level === 1) {
    // Le repère 1 reste toujours en bas - position fixe
    return {
      bottom: '20px' // Position fixe depuis le bas - tient compte de l'ascenseur horizontal
    }
  } else {
    // Utiliser la même fonction de calcul que VelocityLane
    const percentage = getVelocityPosition(level, 100)

    // Calculer la position en tenant compte de la hauteur des onglets
    // La zone utile commence après les en-têtes d'onglets
    const usableHeightPercentage = ((100 - tabHeaderHeight / uiStore.midiLanesHeight * 100) * 0.96) // 96% pour laisser l'espace du repère 1
    const adjustedPercentage = tabHeaderHeight / uiStore.midiLanesHeight * 100 + (percentage * usableHeightPercentage)

    return {
      top: adjustedPercentage + '%'
    }
  }
}

// Synchronisation du scroll horizontal
const syncHorizontalScroll = (source) => {
  const scrollLeft = source.scrollLeft

  if (source !== timelineScrollRef.value) {
    timelineScrollRef.value.scrollLeft = scrollLeft
  }
  if (source !== pianoGridScrollRef.value) {
    pianoGridScrollRef.value.scrollLeft = scrollLeft
  }
  if (source !== midiLanesScrollRef.value) {
    midiLanesScrollRef.value.scrollLeft = scrollLeft
  }
}

// Synchronisation du scroll vertical (Piano + Grid)
const syncVerticalScroll = (scrollTop) => {
  if (pianoGridContainerRef.value) {
    pianoGridContainerRef.value.scrollTop = scrollTop
  }
  // Synchroniser aussi les piano keys
  if (pianoKeysContainerRef.value) {
    pianoKeysContainerRef.value.scrollTop = scrollTop
  }
}

// Redimensionnement TrackList
const startResizeTrackList = (e) => {
  e.preventDefault()
  isResizingTrackList = true
  startX = e.clientX
  startWidth = uiStore.trackListWidth
  document.body.style.cursor = 'col-resize'
  document.body.style.userSelect = 'none'
  document.addEventListener('mousemove', resizeTrackList)
  document.addEventListener('mouseup', stopResizeTrackList)
}

const resizeTrackList = (e) => {
  if (!isResizingTrackList) return
  e.preventDefault()
  const deltaX = e.clientX - startX
  const newWidth = Math.max(200, Math.min(600, startWidth + deltaX))
  uiStore.setTrackListWidth(newWidth)
}

const stopResizeTrackList = () => {
  isResizingTrackList = false
  document.body.style.cursor = ''
  document.body.style.userSelect = ''
  document.removeEventListener('mousemove', resizeTrackList)
  document.removeEventListener('mouseup', stopResizeTrackList)
}

// Redimensionnement MidiLanes
const startResizeMidiLanes = (e) => {
  e.preventDefault()
  isResizingMidiLanes = true
  startY = e.clientY
  startHeight = uiStore.midiLanesHeight
  document.body.style.cursor = 'row-resize'
  document.body.style.userSelect = 'none'
  document.addEventListener('mousemove', resizeMidiLanes)
  document.addEventListener('mouseup', stopResizeMidiLanes)
}

const resizeMidiLanes = (e) => {
  if (!isResizingMidiLanes) return
  e.preventDefault()
  const deltaY = startY - e.clientY // Inverser le delta pour un comportement correct
  const newHeight = Math.max(100, Math.min(400, startHeight + deltaY))
  uiStore.setMidiLanesHeight(newHeight)
}

const stopResizeMidiLanes = () => {
  isResizingMidiLanes = false
  document.body.style.cursor = ''
  document.body.style.userSelect = ''
  document.removeEventListener('mousemove', resizeMidiLanes)
  document.removeEventListener('mouseup', stopResizeMidiLanes)
}

onMounted(() => {
  // Setup scroll synchronization
  if (timelineScrollRef.value) {
    timelineScrollRef.value.addEventListener('scroll', (e) => syncHorizontalScroll(e.target))
  }
  if (pianoGridScrollRef.value) {
    pianoGridScrollRef.value.addEventListener('scroll', (e) => {
      // Synchronisation horizontale
      syncHorizontalScroll(e.target)
      // Synchronisation verticale avec PianoKeys
      if (pianoKeysContainerRef.value) {
        pianoKeysContainerRef.value.scrollTop = e.target.scrollTop
      }
    })
  }
  if (midiLanesScrollRef.value) {
    midiLanesScrollRef.value.addEventListener('scroll', (e) => syncHorizontalScroll(e.target))
  }

  // Exposer les fonctions de synchronisation au store
  uiStore.setSyncFunctions({
    syncHorizontalScroll,
    syncVerticalScroll
  })
})

onUnmounted(() => {
  document.removeEventListener('mousemove', resizeTrackList)
  document.removeEventListener('mouseup', stopResizeTrackList)
  document.removeEventListener('mousemove', resizeMidiLanes)
  document.removeEventListener('mouseup', stopResizeMidiLanes)
})
</script>

<style scoped>
.midi-editor {
  height: calc(100vh - 16px);
  display: flex;
  flex-direction: column;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.main-content {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.left-column {
  background: #f5f5f5;
  border-right: 1px solid #ddd;
  min-width: 200px;
  max-width: 600px;
}

.vertical-splitter {
  width: 4px;
  background: #ddd;
  cursor: col-resize;
  user-select: none;
  position: relative;
  z-index: 10;
}

.vertical-splitter:hover {
  background: #999;
}

.right-column {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.timeline-container {
  height: 40px;
  display: flex;
  border-bottom: 1px solid #ddd;
  background: #fafafa;
}

.timeline-spacer {
  flex-shrink: 0;
  border-right: 1px solid #ddd;
  background: #f0f0f0;
}

.timeline-scroll {
  flex: 1;
  overflow-x: hidden;
  overflow-y: hidden;
}

.piano-grid-container {
  flex: 1;
  display: flex;
  overflow: hidden; /* Masquer les barres de défilement ici */
}

.piano-keys-container {
  width: v-bind('uiStore.pianoKeysWidth + "px"');
  flex-shrink: 0;
  border-right: 1px solid #ddd;
  background: #f8f8f8;
  overflow: hidden; /* Masquer la barre de défilement verticale sur les touches */
}

.piano-grid-scroll {
  flex: 1;
  overflow-x: auto;
  overflow-y: auto;
}

/* Masquer la barre de défilement horizontale uniquement */
.piano-grid-scroll::-webkit-scrollbar:horizontal {
  display: none;
}

/* Pour Firefox - masquer seulement le scrollbar horizontal */
.piano-grid-scroll {
  scrollbar-width: thin;
}

/* Alternative plus robuste pour masquer le scroll horizontal */
.piano-grid-scroll {
  overflow-x: hidden; /* Changer ça pour vraiment masquer le scroll horizontal */
}

.horizontal-splitter {
  height: 4px;
  background: #ddd;
  cursor: row-resize;
  user-select: none;
  position: relative;
  z-index: 10;
}

.horizontal-splitter:hover {
  background: #999;
}

.midi-lanes-container {
  display: flex;
  border-top: 1px solid #ddd;
  background: #fafafa;
  min-height: 100px;
  max-height: 400px;
  overflow: hidden; /* Important : empêcher les barres de défilement ici */
}

.midi-lanes-spacer {
  flex-shrink: 0;
  border-right: 1px solid #ddd;
  background: #f0f0f0;
  position: relative;
  height: 100%; /* Utiliser toute la hauteur disponible */
  overflow: hidden; /* Empêcher le débordement */
}

.midi-lanes-scroll {
  flex: 1;
  overflow-x: auto;
  overflow-y: hidden;
  /* Garder seulement le défilement horizontal pour les MIDI lanes */
}

/* Styles pour l'échelle de vélocité */
.velocity-scale {
  position: absolute;
  top: 0;
  right: 0;
  width: 40px;
  height: 100%;
  background: rgba(240, 240, 240, 0.9);
  border-left: 1px solid #ccc;
  padding: 4px 0; /* Ajouter un padding pour éviter les débordements */
  box-sizing: border-box;
}

.velocity-scale-line {
  position: absolute;
  left: 0;
  width: 100%;
  height: 1px;
  border-top: 1px solid #999;
  pointer-events: none;
}

.velocity-scale-label {
  position: absolute;
  right: 2px;
  top: -6px; /* Réduire le décalage */
  font-size: 10px;
  color: #666;
  background: rgba(240, 240, 240, 0.9);
  padding: 0 2px;
  border-radius: 2px;
  user-select: none;
  white-space: nowrap;
}

.velocity-scale-line.max-velocity {
  border-top-color: #ff6b35;
  border-top-width: 2px; /* Ligne plus épaisse */
}

.velocity-scale-line.max-velocity .velocity-scale-label {
  color: #ff6b35;
  font-weight: bold;
  top: 2px; /* Positionner le label en dessous de la ligne pour 127 */
}

/*---*/
.velocity-display {
  position: absolute;
  top: 10px;
  left: 10px;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 14px;
  font-weight: bold;
  z-index: 100;
  min-width: 30px;
  text-align: center;
}
</style>
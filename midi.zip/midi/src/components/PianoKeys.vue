<template>
  <div class="piano-keys" :style="{ height: uiStore.totalPianoHeight + 'px' }">
    <!-- Touches blanches d'abord -->
    <div
      v-for="note in whiteNotes"
      :key="'white-' + note.midi"
      class="piano-key white-key"
      :class="isCNote(note.name) ? 'c-note' : ''"
      :style="whiteKeyStyle(note)"
      :note="note.name"
    >
      <span class="note-label" v-if="isCNote(note.name)">{{ note.name }}</span>
    </div>

    <!-- Touches noires par-dessus -->
    <div
      v-for="note in blackNotes"
      :key="'black-' + note.midi"
      class="piano-key black-key"
      :style="blackKeyStyle(note)"
      :noteName="note.name"
    >
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useUIStore } from '@/stores/ui'

const uiStore = useUIStore()

const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
const blackKeys = [1, 3, 6, 8, 10] // C#, D#, F#, G#, A#

const midiNotes = computed(() => {
  const notes = []
  for (let midi = 127; midi >= 0; midi--) {
    const octave = Math.floor(midi / 12) - 1
    const noteIndex = midi % 12
    const noteName = noteNames[noteIndex]
    const isBlack = blackKeys.includes(noteIndex)

    notes.push({
      midi,
      name: `${noteName}${octave}`,
      isBlack,
      noteIndex,
      y: uiStore.midiNoteToY(midi)
    })
  }
  console.log(notes)
  return notes
})

const whiteNotes = computed(() => {
  return midiNotes.value.filter(note => !note.isBlack)
})

const blackNotes = computed(() => {
  return midiNotes.value.filter(note => note.isBlack)
})

const isCNote = (noteName) => {
  return /^C-?[0-9]+$/.test(noteName)
}

// Calculer les positions pour que les touches blanches se touchent
const whiteKeyPositions = computed(() => {
  const positions = new Map()
  let currentY = 0

  // Parcourir toutes les notes de bas en haut (C0 vers C8)
  for (let midi = 0; midi <= 127; midi++) {
    const noteIndex = midi % 12
    const isBlack = blackKeys.includes(noteIndex)

    if (!isBlack) {
      // Pour les touches blanches, assigner une position continue
      positions.set(midi, currentY)
      currentY += uiStore.keyHeight * 2 // Doubler la hauteur
    }
  }

  return positions
})

const whiteKeyStyle = (note) => {
  const y = whiteKeyPositions.value.get(note.midi)
  return {
    top: (uiStore.totalPianoHeight - y - uiStore.keyHeight * 2) + 'px', // Inverser pour avoir C0 en bas
    height: (uiStore.keyHeight * 2) + 'px', // Hauteur doublée
    left: '0px',
    width: '100%',
    zIndex: 1
  }
}

const blackKeyStyle = (note) => {
  // Les touches noires doivent être positionnées au milieu des touches blanches
  // Pour cela, on trouve la touche blanche suivante (plus grave) et on centre dessus

  let whiteKeyBelow = null
  for (let midi = note.midi - 1; midi >= 0; midi--) {
    const noteIndex = midi % 12
    if (!blackKeys.includes(noteIndex)) {
      whiteKeyBelow = midi
      break
    }
  }

  if (whiteKeyBelow !== null) {
    const whiteKeyY = whiteKeyPositions.value.get(whiteKeyBelow)
    if (whiteKeyY !== undefined) {
      const whiteKeyTop = uiStore.totalPianoHeight - whiteKeyY - uiStore.keyHeight * 2
      const centeredY = whiteKeyTop - (uiStore.keyHeight * 2 - uiStore.keyHeight) / 2

      return {
        top: centeredY + 'px',
        height: uiStore.keyHeight + 'px',
        left: '0px',
        width: '60%',
        zIndex: 2
      }
    }
  }

  // Fallback si on ne trouve pas la touche blanche
  return {
    top: note.y + 'px',
    height: uiStore.keyHeight + 'px',
    left: '0px',
    width: '60%',
    zIndex: 2
  }
}
</script>

<style scoped>
.piano-keys {
  position: relative;
  width: 100%;
  background: #f8f8f8;
}

.piano-key {
  position: absolute;
  border: 1px solid #ccc;
  display: flex;
  align-items: center;
  cursor: pointer;
  box-sizing: border-box;
}

.white-key {
  background: #ffffff;
  border-color: #ddd;
}

.white-key:hover {
  background: #f0f0f0;
}

.black-key {
  background: #333;
  border-color: #000;
  border-radius: 0 3px 3px 0; /* Arrondi seulement à droite */
}

.black-key:hover {
  background: #555;
}

.note-label {
  font-size: 12px;
  color: #666;
  padding-right: 8px;
  margin-left: auto; /* Pousse le label vers la droite */
  user-select: none;
}

.c-note {
  background-color: #e6f7ff;
}
</style>
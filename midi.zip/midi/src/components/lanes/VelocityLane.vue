<template>
  <div class="velocity-lane" ref="velocityLaneRef">
    <!-- Overlay invisible pour capturer les événements pendant le drag -->
    <div
      v-if="isDragging"
      class="drag-overlay"
      @mousemove="handleDragMove"
      @mouseup="handleDragEnd"
      @mouseleave="handleDragEnd"
    ></div>

    <!-- Grille de mesures -->
    <div class="measures-grid" :style="{ width: totalMeasures * uiStore.pixelsPerMeasure + 'px' }">
      <!-- Lignes horizontales de l'échelle de vélocité -->
      <div
        v-for="level in velocityLevels"
        :key="level"
        class="velocity-scale-line"
        :class="{ 'max-velocity': level === 127 }"
        :style="getVelocityScaleLineStyle(level)"
      ></div>

      <!-- Lignes verticales pour les mesures -->
      <div
        v-for="measure in visibleMeasures"
        :key="measure"
        class="measure-line"
        :style="{ left: measureToPixels(measure) + 'px' }"
      ></div>

      <!-- Barres de vélocité pour chaque note du midiStore -->
      <div
        v-for="note in selectedTrackNotes"
        :key="note.id"
        class="velocity-bar"
        :style="getVelocityBarStyle(note)"
        @mousedown="handleDragStart($event, note)"
      >
        <div class="velocity-bar-fill" :style="getVelocityFillStyle(note)"></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useUIStore } from '@/stores/ui'
import { useMidiStore } from '@/stores/midi'

const props = defineProps({
  totalMeasures: {
    type: Number,
    default: 32
  },
  visibleMeasures: {
    type: Array,
    default: () => []
  },
  measureToPixels: {
    type: Function,
    required: true
  }
})

const uiStore = useUIStore()
const midiStore = useMidiStore()
const velocityLaneRef = ref(null)

// État du drag
const isDragging = ref(false)
const currentNote = ref(null)

// Niveaux de vélocité à afficher (même que dans App.vue)
const velocityLevels = [127, 96, 64, 32, 1]

// Récupérer les notes du store MIDI
const selectedTrackNotes = computed(() => midiStore.getSelectedTrackNotes)

// Propriétés calculées
const laneHeight = computed(() => uiStore.midiLanesHeight - 40) // Moins la hauteur des onglets

// Fonction pour calculer la position d'une vélocité (identique à App.vue)
const getVelocityPosition = (velocity) => {
  const maxVelocity = 127
  const minVelocity = 1
  // Calculer la position en pourcentage (127 en haut = 0%, 1 en bas = 100%)
  const percentage = (maxVelocity - velocity) / (maxVelocity - minVelocity)
  return percentage
}

// Style pour les lignes horizontales de l'échelle
const getVelocityScaleLineStyle = (level) => {
  if (level === 1) {
    // Le repère 1 reste toujours en bas
    return {
      bottom: '2px',
      top: 'auto'
    }
  } else {
    // Utiliser la même fonction de calcul que App.vue
    const percentage = getVelocityPosition(level)
    // Ajuster pour la zone utilisable (96% pour laisser l'espace du repère 1)
    const adjustedPercentage = percentage * 96

    return {
      top: adjustedPercentage + '%',
      bottom: 'auto'
    }
  }
}

// Styles pour les barres de vélocité - utiliser la même logique que les notes
const getVelocityBarStyle = (note) => {
  // Position X : utiliser exactement le même calcul que MidiNote.vue
  const leftPosition = uiStore.beatsToPixels(note.start)

  return {
    left: leftPosition + 'px',
    width: '8px',  // Largeur fixe 8px comme demandé
    height: '100%',
    position: 'absolute',
    bottom: '0'
  }
}

const getVelocityFillStyle = (note) => {
  // Assurer une hauteur minimale de 4px pour les barres avec vélocité 1
  const minHeightPixels = 4
  const heightPercentage = Math.max((note.velocity / 127) * 100, (minHeightPixels / laneHeight.value) * 100)

  return {
    height: heightPercentage + '%',
    backgroundColor: getVelocityColor(note.velocity),
    transition: isDragging.value ? 'none' : 'height 0.1s ease, background-color 0.1s ease'
  }
}

// Couleur basée sur la vélocité (inversée : rouge = fort)
const getVelocityColor = (velocity) => {
  if (velocity >= 96) return '#ff4444'      // Rouge pour fort (127)
  if (velocity >= 64) return '#ff8800'      // Orange pour bon
  if (velocity >= 32) return '#88bb00'      // Vert pour moyen
  return '#4488ff'                          // Bleu pour faible (1)
}

// Calcul de la vélocité basée sur la position Y
const calculateVelocityFromY = (clientY) => {
  if (!velocityLaneRef.value) return 64

  const rect = velocityLaneRef.value.getBoundingClientRect()
  const relativeY = clientY - rect.top

  // Limiter la zone de calcul pour éviter que la barre disparaisse
  // Laisser 4px en bas pour la vélocité minimale
  const minYPixels = 4
  const maxUsableHeight = laneHeight.value - minYPixels

  // Contraindre relativeY dans la zone utilisable
  const constrainedY = Math.max(0, Math.min(maxUsableHeight, relativeY))

  const percentage = 1 - (constrainedY / maxUsableHeight) // Inverse car 0 en haut = velocity max

  return Math.max(1, Math.min(127, Math.round(percentage * 127)))
}

// Gestionnaires d'événements
const handleDragStart = (event, note) => {
  if (event.button !== 0) return // Seulement clic gauche

  isDragging.value = true
  currentNote.value = note

  // Afficher la valeur dans la zone à gauche
  uiStore.showVelocityDisplay(note.velocity)

  event.preventDefault()
  event.stopPropagation()
}

const handleDragMove = (event) => {
  if (!isDragging.value || !currentNote.value) return

  // Calculer la nouvelle vélocité
  const newVelocity = calculateVelocityFromY(event.clientY)

  // Mettre à jour la note dans le store MIDI
  midiStore.updateNote(currentNote.value.id, { velocity: newVelocity })

  // Mettre à jour l'affichage
  uiStore.updateVelocityDisplay(newVelocity)

  event.preventDefault()
}

const handleDragEnd = (event) => {
  if (!isDragging.value) return

  // Finaliser l'édition
  isDragging.value = false
  const editedNote = currentNote.value
  currentNote.value = null

  // Masquer l'affichage
  uiStore.hideVelocityDisplay()

  if (editedNote) {
    console.log(`Note ${editedNote.id} velocity changed to ${editedNote.velocity}`)
  }
}

// Lifecycle
onUnmounted(() => {
  uiStore.hideVelocityDisplay()
})
</script>

<style scoped>
.velocity-lane {
  position: relative;
  height: 100%;
  background: #fafafa;
  overflow: hidden;
  user-select: none;
}

.drag-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 9999;
  cursor: ns-resize;
  background: transparent;
}

.measures-grid {
  position: relative;
  height: 100%;
  min-height: 100px;
}

.measure-line {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  background: #e0e0e0;
  pointer-events: none;
}

/* Lignes horizontales pour l'échelle de vélocité */
.velocity-scale-line {
  position: absolute;
  left: 0;
  right: 0;
  height: 1px;
  background: #d0d0d0;
  pointer-events: none;
  z-index: 1;
}

.velocity-scale-line.max-velocity {
  /*
  background: #ff6b35;
  height: 2px;
  */
}

.velocity-bar {
  cursor: ns-resize;
  border-radius: 1px;
  z-index: 2; /* Au-dessus des lignes d'échelle */
}

.velocity-bar:hover {
  box-shadow: 0 0 4px rgba(33, 150, 243, 0.5);
}

.velocity-bar-fill {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  border-radius: 1px;
  min-height: 4px; /* Hauteur minimale pour garantir la visibilité */
}
</style>
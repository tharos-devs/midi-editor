<template>
  <div class="timeline" :style="{ width: timelineWidth + 'px' }">
    <div class="timeline-ruler">
      <div
        v-for="measure in visibleMeasures"
        :key="measure"
        class="measure-mark"
        :style="{ left: measureToPixels(measure) + 'px' }"
      >
        <div class="measure-number">{{ measure }}</div>
        <div class="beat-marks">
          <div
            v-for="beat in beatsInMeasure"
            :key="beat"
            class="beat-mark"
            :style="{ left: (beat - 1) * beatWidth + 'px' }"
          ></div>
        </div>
      </div>
    </div>

    <div class="time-signature">
      {{ uiStore.beatsPerMeasure }}/{{ uiStore.beatNote }}
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useUIStore } from '../stores/ui'

const uiStore = useUIStore()

const totalMeasures = 32
const timelineWidth = computed(() => totalMeasures * uiStore.pixelsPerMeasure)
const beatWidth = computed(() => uiStore.pixelsPerBeat)
const beatsInMeasure = computed(() => Array.from({ length: uiStore.beatsPerMeasure }, (_, i) => i + 1))

const visibleMeasures = computed(() => {
  return Array.from({ length: totalMeasures }, (_, i) => i + 1)
})

const measureToPixels = (measure) => {
  return (measure - 1) * uiStore.pixelsPerMeasure
}
</script>

<style scoped>
.timeline {
  height: 100%;
  position: relative;
  background: linear-gradient(to bottom, #fafafa 0%, #f0f0f0 100%);
  min-width: 100%;
}

.timeline-ruler {
  height: 100%;
  position: relative;
}

.measure-mark {
  position: absolute;
  top: 0;
  height: 100%;
  border-left: 2px solid #333;
}

.measure-number {
  position: absolute;
  top: 4px;
  left: 4px;
  font-size: 11px;
  font-weight: bold;
  color: #333;
}

.beat-marks {
  position: relative;
  height: 100%;
}

.beat-mark {
  position: absolute;
  top: 20px;
  height: calc(100% - 20px);
  border-left: 1px solid #666;
}

.time-signature {
  position: absolute;
  top: 4px;
  right: 8px;
  font-size: 12px;
  font-weight: bold;
  color: #333;
  background: rgba(255, 255, 255, 0.8);
  padding: 2px 6px;
  border-radius: 3px;
}
</style>

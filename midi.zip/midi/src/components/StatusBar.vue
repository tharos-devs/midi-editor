<template>
  <div class="status-bar">
    <div class="status-section">
      <span class="status-label">Position:</span>
      <span class="status-value">{{ currentPosition }}</span>
    </div>

    <div class="status-section">
      <span class="status-label">Tempo:</span>
      <span class="status-value">{{ tempo }} BPM</span>
    </div>

    <div class="status-section">
      <span class="status-label">Signature:</span>
      <span class="status-value">{{ uiStore.beatsPerMeasure }}/{{ uiStore.beatNote }}</span>
    </div>

    <div class="status-section">
      <span class="status-label">Zoom:</span>
      <span class="status-value">H: {{ Math.round(uiStore.horizontalZoom * 100) }}% - V: {{ Math.round(uiStore.verticalZoom * 100) }}%</span>
    </div>

    <div class="status-section ml-auto">
      <span class="status-label">Pistes:</span>
      <span class="status-value">{{ totalTracks }}</span>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useUIStore } from '@/stores/ui'

const uiStore = useUIStore()

const currentPosition = ref('1.1.1')
const tempo = ref(120)
const totalTracks = ref(4)
</script>

<style scoped>
.status-bar {
  height: 30px;
  background: #f8f9fa;
  border-top: 1px solid #e6e6e6;
  display: flex;
  align-items: center;
  padding: 0 16px;
  font-size: 12px;
}

.status-section {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-right: 24px;
}

.status-section.ml-auto {
  margin-left: auto;
  margin-right: 0;
}

.status-label {
  color: #666;
  font-weight: 500;
}

.status-value {
  color: #333;
  font-family: monospace;
}
</style>

Smart, efficient model for everyday use En savoir plus
Artéfacts

Contenu
Aucun contenu ajouté pour le moment
Ajoutez des images, PDF, documents, feuilles de calcul et plus pour résumer, analyser et interroger le contenu avec Claude.
<template>
  <div class="track-list">
    <div class="track-list-header">
      <h3>Pistes</h3>
      <el-button :icon="Plus" size="small" type="primary" @click="addNewTrack">
        Ajouter
      </el-button>
    </div>

    <div class="track-list-content">
      <div
        v-for="track in tracks"
        :key="track.id"
        class="track-item"
        :class="{ active: selectedTrack === track.id }"
        @click="selectTrack(track.id)"
      >
        <div class="track-info">
          <div class="track-name">{{ track.name }}</div>
          <div class="track-instrument">{{ track.instrument }}</div>
          <div class="track-details">
            Ch{{ track.channel + 1 }} • Vol{{ track.volume }} • {{ getNoteCount(track.id) }} notes
          </div>
        </div>
        <div class="track-controls">
          <el-button
            :icon="VideoPlay"
            size="small"
            text
            :class="{ active: track.solo }"
            @click.stop="toggleSolo(track.id)"
            title="Solo"
          />
          <el-button
            :icon="Mute"
            size="small"
            text
            :class="{ active: track.mute }"
            @click.stop="toggleMute(track.id)"
            title="Mute"
          />
          <el-button
            :icon="Close"
            size="small"
            text
            type="danger"
            @click.stop="deleteSelectedTrack(track.id)"
            title="Supprimer"
          />
        </div>
      </div>

      <!-- Message si aucune piste -->
      <div v-if="tracks.length === 0" class="no-tracks">
        <p>Aucune piste disponible</p>
        <p class="hint">Chargez un fichier MIDI ou ajoutez une piste</p>
      </div>
    </div>

    <!-- Informations sur la piste sélectionnée -->
    <div v-if="selectedTrackInfo" class="selected-track-info">
      <h4>Piste sélectionnée</h4>
      <div class="track-stats">
        <div class="stat">
          <span class="label">Notes :</span>
          <span class="value">{{ selectedTrackNotes.length }}</span>
        </div>
        <div class="stat">
          <span class="label">Événements CC :</span>
          <span class="value">{{ selectedTrackCC.length }}</span>
        </div>
        <div class="stat">
          <span class="label">Canal :</span>
          <span class="value">{{ selectedTrackInfo.channel + 1 }}</span>
        </div>
        <div class="stat">
          <span class="label">Programme :</span>
          <span class="value">{{ selectedTrackInfo.program }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { Plus, VideoPlay, Mute, Close } from '@element-plus/icons-vue'
import { useMidiStore } from '@/stores/midi'
import { ElMessageBox, ElMessage } from 'element-plus'

const midiStore = useMidiStore()

// Computed pour récupérer les données du store
const tracks = computed(() => midiStore.tracks)
const selectedTrack = computed(() => midiStore.selectedTrack)
const selectedTrackInfo = computed(() => midiStore.getSelectedTrack)
const selectedTrackNotes = computed(() => midiStore.getSelectedTrackNotes)
const selectedTrackCC = computed(() => midiStore.getSelectedTrackCC)

// Sélectionner une piste via le store
const selectTrack = (id) => {
  midiStore.selectTrack(id)
}

// Compter les notes pour une piste
const getNoteCount = (trackId) => {
  return midiStore.getNotesByTrack(trackId).length
}

// Basculer le mode solo d'une piste
const toggleSolo = (trackId) => {
  const track = midiStore.getTrackById(trackId)
  if (track) {
    midiStore.updateTrack(trackId, { solo: !track.solo })
  }
}

// Basculer le mode mute d'une piste
const toggleMute = (trackId) => {
  const track = midiStore.getTrackById(trackId)
  if (track) {
    midiStore.updateTrack(trackId, { mute: !track.mute })
  }
}

// Ajouter une nouvelle piste
const addNewTrack = () => {
  const trackNumber = tracks.value.length + 1
  const newTrackId = midiStore.addTrack({
    name: `Nouvelle Piste ${trackNumber}`,
    instrument: 'Acoustic Grand Piano',
    program: 0,
    channel: Math.min(trackNumber - 1, 15), // MIDI channels 0-15
    volume: 100,
    pan: 64
  })

  // Sélectionner automatiquement la nouvelle piste
  midiStore.selectTrack(newTrackId)

  ElMessage.success('Nouvelle piste ajoutée')
}

// Supprimer une piste avec confirmation
const deleteSelectedTrack = async (trackId) => {
  const track = midiStore.getTrackById(trackId)
  if (!track) return

  // Compter le nombre de notes dans cette piste
  const noteCount = midiStore.getNotesByTrack(trackId).length

  let message = `Êtes-vous sûr de vouloir supprimer la piste "${track.name}" ?`
  if (noteCount > 0) {
    message += `\n\nCette action supprimera également ${noteCount} note(s).`
  }

  try {
    await ElMessageBox.confirm(
      message,
      'Confirmer la suppression',
      {
        confirmButtonText: 'Supprimer',
        cancelButtonText: 'Annuler',
        type: 'warning',
        confirmButtonClass: 'el-button--danger'
      }
    )

    // Supprimer la piste via le store
    midiStore.deleteTrack(trackId)

    ElMessage.success('Piste supprimée')

  } catch {
    // L'utilisateur a annulé
  }
}
</script>
<style scoped>
.track-list {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.track-list-header {
  padding: 16px;
  border-bottom: 1px solid #e6e6e6;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.track-list-header h3 {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
}

.track-list-content {
  flex: 1;
  overflow-y: auto;
}

.track-item {
  padding: 12px 16px;
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: background-color 0.2s;
}

.track-item:hover {
  background: #f8f9fa;
}

.track-item.active {
  background: #e6f7ff;
  border-color: #1890ff;
}

.track-info {
  flex: 1;
  min-width: 0; /* Pour permettre l'ellipsis */
}

.track-name {
  font-weight: 500;
  font-size: 13px;
  margin-bottom: 2px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.track-instrument {
  font-size: 11px;
  color: #666;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 1px;
}

.track-details {
  font-size: 10px;
  color: #999;
}

.track-controls {
  display: flex;
  gap: 2px;
  flex-shrink: 0;
}

.track-controls .el-button {
  padding: 4px;
  min-width: auto;
}

.track-controls .el-button.active {
  background: #1890ff;
  color: white;
}

.track-controls .el-button.active:hover {
  background: #40a9ff;
}

.no-tracks {
  padding: 32px 16px;
  text-align: center;
  color: #999;
}

.no-tracks p {
  margin: 8px 0;
}

.no-tracks .hint {
  font-size: 12px;
  color: #ccc;
}

/* Animations pour les transitions */
.track-item {
  transition: all 0.2s ease;
}

.track-controls .el-button {
  transition: all 0.2s ease;
}
</style>
<template>
  <div class="piano-grid" :style="gridStyle">
    <!-- Couche de fond avec les lignes - en position absolue pour dépasser les limites -->
    <div class="grid-background-fixed" :style="gridBackgroundStyle">
      <!-- Lignes horizontales (notes) - seulement les touches blanches avec espacement correct -->
      <div
        v-for="note in whiteNotes"
        :key="note.midi"
        class="note-line white-note-line"
        :style="{
          top: (uiStore.totalPianoHeight - whiteKeyPositions.get(note.midi) - uiStore.keyHeight * 2) + 'px',
          height: (uiStore.keyHeight * 2) + 'px',
          width: gridWidth + 'px',
          left: '0px'
        }"
        :note="note.name"
      ></div>

      <!-- Lignes horizontales pour les touches noires (optionnel, pour visualisation) -->
      <div
        v-for="note in blackNotes"
        :key="note.midi"
        class="note-line black-note-line"
        :style="{
          top: getBlackNotePosition(note) + 'px',
          height: uiStore.keyHeight + 'px',
          width: gridWidth + 'px',
          left: '0px'
        }"
        :note="note.name"
      ></div>

      <!-- Lignes verticales (mesures et temps) -->
      <div
        v-for="measure in allMeasures"
        :key="`measure-${measure}`"
        class="measure-line"
        :style="{
          left: measureToPixels(measure) + 'px',
          height: uiStore.totalPianoHeight + 'px',
          top: '0px'
        }"
      ></div>

      <div
        v-for="(measure, measureIndex) in allMeasures"
        :key="`beats-${measure}`"
      >
        <div
          v-for="beat in beatsInMeasure"
          :key="`beat-${measure}-${beat}`"
          class="beat-line"
          :style="{
            left: measureToPixels(measure) + (beat - 1) * uiStore.pixelsPerBeat + 'px',
            height: uiStore.totalPianoHeight + 'px',
            top: '0px'
          }"
        ></div>
      </div>
    </div>

    <!-- Notes MIDI utilisant le nouveau composant -->
    <div class="notes-layer">
      <MidiNote
        v-for="note in selectedTrackNotes"
        :key="note.id"
        :note="note"
        :white-key-positions="whiteKeyPositions"
        :black-keys="blackKeys"
      />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useUIStore } from '@/stores/ui'
import { useMidiStore } from '@/stores/midi'
import MidiNote from '@/components/MidiNote.vue'

const uiStore = useUIStore()
const midiStore = useMidiStore()

const selectedTrackNotes = computed(() => midiStore.getSelectedTrackNotes)

const totalMeasures = 32

const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
const blackKeys = [1, 3, 6, 8, 10] // C#, D#, F#, G#, A#

const gridWidth = computed(() => totalMeasures * uiStore.pixelsPerMeasure)

const gridStyle = computed(() => ({
  width: gridWidth.value + 'px',
  height: uiStore.totalPianoHeight + 'px'
}))

const gridBackgroundStyle = computed(() => ({
  width: gridWidth.value + 'px',
  height: uiStore.totalPianoHeight + 'px'
}))

// Utiliser la même logique que dans PianoKeys pour les notes MIDI
const midiNotes = computed(() => {
  const notes = []
  for (let midi = 127; midi >= 0; midi--) {
    const octave = Math.floor(midi / 12) - 1
    const noteIndex = midi % 12
    const noteName = noteNames[noteIndex]
    const isBlack = blackKeys.includes(noteIndex)

    notes.push({
      midi,
      name: `${noteName}${octave}`,
      isBlack,
      noteIndex,
      y: uiStore.midiNoteToY(midi)
    })
  }
  return notes
})

const whiteNotes = computed(() => {
  return midiNotes.value.filter(note => !note.isBlack)
})

const blackNotes = computed(() => {
  return midiNotes.value.filter(note => note.isBlack)
})

// Calculer les positions des touches blanches (même logique que PianoKeys)
const whiteKeyPositions = computed(() => {
  const positions = new Map()
  let currentY = 0

  // Parcourir toutes les notes de bas en haut (C0 vers C8)
  for (let midi = 0; midi <= 127; midi++) {
    const noteIndex = midi % 12
    const isBlack = blackKeys.includes(noteIndex)

    if (!isBlack) {
      // Pour les touches blanches, assigner une position continue
      positions.set(midi, currentY)
      currentY += uiStore.keyHeight * 2 // Doubler la hauteur
    }
  }

  return positions
})

// Position des touches noires (même logique que PianoKeys)
const getBlackNotePosition = (note) => {
  let whiteKeyBelow = null
  for (let midi = note.midi - 1; midi >= 0; midi--) {
    const noteIndex = midi % 12
    if (!blackKeys.includes(noteIndex)) {
      whiteKeyBelow = midi
      break
    }
  }

  if (whiteKeyBelow !== null) {
    const whiteKeyY = whiteKeyPositions.value.get(whiteKeyBelow)
    if (whiteKeyY !== undefined) {
      const whiteKeyTop = uiStore.totalPianoHeight - whiteKeyY - uiStore.keyHeight * 2
      return whiteKeyTop - (uiStore.keyHeight * 2 - uiStore.keyHeight) / 2
    }
  }

  // Fallback
  return note.y
}

const allMeasures = computed(() => {
  return Array.from({ length: totalMeasures }, (_, i) => i + 1)
})

const beatsInMeasure = computed(() => {
  return Array.from({ length: uiStore.beatsPerMeasure }, (_, i) => i + 1)
})

const measureToPixels = (measure) => {
  return (measure - 1) * uiStore.pixelsPerMeasure
}
</script>

<style scoped>
.piano-grid {
  position: relative;
  background: #ffffff;
  /* Pas d'overflow ici - c'est le conteneur parent qui gère le scroll */
}

.grid-background-fixed {
  position: absolute;
  top: 0;
  left: 0;
  pointer-events: none;
  z-index: 1; /* Derrière les notes mais visible */
}

.note-line {
  position: absolute;
  pointer-events: none;
}

.white-note-line {
  background: rgba(255, 255, 255, 0.8);
  border-bottom: 1px solid #f0f0f0;
  border-top: 1px solid #f0f0f0;
}

.black-note-line {
  background: rgba(245, 245, 245, 0.8);
  border-bottom: 1px solid #e0e0e0;
  border-top: 1px solid #e0e0e0;
}

.measure-line {
  position: absolute;
  top: 0;
  border-left: 2px solid #ddd;
  pointer-events: none;
}

.beat-line {
  position: absolute;
  top: 0;
  border-left: 1px solid #e6e6e6;
  pointer-events: none;
}

.notes-layer {
  position: relative;
  width: 100%;
  height: 100%;
  z-index: 10;
}
</style>
<template>
  <div
    class="midi-note"
    :class="{
      selected: isSelected,
      dragging: isDragging,
      resizing: isResizing
    }"
    :style="noteStyle"
    @mousedown="onMouseDown"
    @mousemove="onMouseMove"
    @mouseleave="onMouseLeave"
    ref="noteRef"
  >
    <!-- Contenu de la note -->
    <div class="note-content">
      <span class="note-name">{{ noteName }}</span>
      <span class="note-velocity">{{ note.velocity }}</span>
    </div>

    <!-- Handle de redimensionnement - toujours visible -->
    <div
      class="resize-handle"
      :class="{ 'resize-hover': showResizeCursor }"
      @mousedown.stop="startResize"
    ></div>

    <!-- Indicateur de snap -->
    <div v-if="showSnapIndicator" class="snap-indicator" :style="snapIndicatorStyle"></div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { useUIStore } from '@/stores/ui'
import { useMidiStore } from '@/stores/midi'

const props = defineProps({
  note: Object,
  whiteKeyPositions: Map,
  blackKeys: Array
})

const uiStore = useUIStore()
const midiStore = useMidiStore()

const noteRef = ref(null)
const isDragging = ref(false)
const isResizing = ref(false)
const showSnapIndicator = ref(false)
const showResizeCursor = ref(false)
const snapIndicatorStyle = ref({})

// Variables pour le dragging
let dragStartX = 0
let dragStartY = 0
let initialStart = 0
let initialMidi = 0
let initialDuration = 0

const isSelected = computed(() => {
  return midiStore.selectedNote?.id === props.note.id
})

const noteName = computed(() => {
  const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
  const octave = Math.floor(props.note.midi / 12) - 1
  const noteIndex = props.note.midi % 12
  return `${noteNames[noteIndex]}${octave}`
})

const noteStyle = computed(() => {
  // Calcul de la position Y (même logique que dans PianoGrid)
  let noteY
  const noteIndex = props.note.midi % 12
  const isBlack = props.blackKeys.includes(noteIndex)

  if (isBlack) {
    noteY = getBlackNotePosition(props.note)
  } else {
    const whiteKeyY = props.whiteKeyPositions.get(props.note.midi)
    noteY = uiStore.totalPianoHeight - whiteKeyY - uiStore.keyHeight * 2
  }

  return {
    left: uiStore.beatsToPixels(props.note.start) + 'px',
    top: noteY + 'px',
    width: uiStore.beatsToPixels(props.note.duration) + 'px',
    height: uiStore.keyHeight + 'px',
    opacity: props.note.velocity / 127,
    zIndex: isSelected.value ? 100 : 10
  }
})

const getBlackNotePosition = (note) => {
  let whiteKeyBelow = null
  for (let midi = note.midi - 1; midi >= 0; midi--) {
    const noteIndex = midi % 12
    if (!props.blackKeys.includes(noteIndex)) {
      whiteKeyBelow = midi
      break
    }
  }

  if (whiteKeyBelow !== null) {
    const whiteKeyY = props.whiteKeyPositions.get(whiteKeyBelow)
    if (whiteKeyY !== undefined) {
      const whiteKeyTop = uiStore.totalPianoHeight - whiteKeyY - uiStore.keyHeight * 2
      return whiteKeyTop - (uiStore.keyHeight * 2 - uiStore.keyHeight) / 2
    }
  }

  return 0
}

const onMouseMove = (e) => {
  if (isDragging.value || isResizing.value) return

  const rect = noteRef.value.getBoundingClientRect()
  const x = e.clientX - rect.left
  const resizeZoneWidth = 8 // Zone de 8px sur le bord droit

  showResizeCursor.value = x >= rect.width - resizeZoneWidth
}

const onMouseLeave = () => {
  if (!isDragging.value && !isResizing.value) {
    showResizeCursor.value = false
  }
}

const onMouseDown = (e) => {
  e.preventDefault()
  e.stopPropagation()

  // Vérifier si on est sur la zone de redimensionnement
  const rect = noteRef.value.getBoundingClientRect()
  const x = e.clientX - rect.left
  const resizeZoneWidth = 8

  if (x >= rect.width - resizeZoneWidth) {
    startResize(e)
    return
  }

  // Sélectionner la note
  midiStore.selectNote(props.note.id)

  // Commencer le drag
  startDrag(e)
}

const startDrag = (e) => {
  isDragging.value = true
  dragStartX = e.clientX
  dragStartY = e.clientY
  initialStart = props.note.start
  initialMidi = props.note.midi

  document.addEventListener('mousemove', onDrag)
  document.addEventListener('mouseup', stopDrag)
  document.body.style.cursor = 'grabbing'
  document.body.style.userSelect = 'none'
}

const onDrag = (e) => {
  if (!isDragging.value) return

  const deltaX = e.clientX - dragStartX
  const deltaY = e.clientY - dragStartY

  // Calcul de la nouvelle position horizontale (en beats)
  const deltaBeats = uiStore.pixelsToBeats(deltaX)
  let newStart = initialStart + deltaBeats

  // Calcul de la nouvelle note MIDI (position verticale)
  const deltaMidi = Math.round(-deltaY / uiStore.keyHeight)
  let newMidi = initialMidi + deltaMidi

  // Contraintes
  newStart = Math.max(0, newStart)
  newMidi = Math.max(0, Math.min(127, newMidi))

  // Afficher l'indicateur de snap
  if (midiStore.snapEnabled) {
    const snappedStart = midiStore.snapToGrid(newStart)
    showSnapIndicator.value = true
    snapIndicatorStyle.value = {
      left: uiStore.beatsToPixels(snappedStart) + 'px',
      top: noteStyle.value.top,
      width: noteStyle.value.width,
      height: noteStyle.value.height
    }
  }

  // Mettre à jour la position en temps réel (sans snap pour la fluidité)
  midiStore.updateNote(props.note.id, {
    start: newStart,
    midi: newMidi
  })
}

const stopDrag = () => {
  if (!isDragging.value) return

  isDragging.value = false
  showSnapIndicator.value = false

  // Appliquer le snap final
  if (midiStore.snapEnabled) {
    const snappedStart = midiStore.snapToGrid(props.note.start)
    midiStore.updateNote(props.note.id, { start: snappedStart })
  }

  document.removeEventListener('mousemove', onDrag)
  document.removeEventListener('mouseup', stopDrag)
  document.body.style.cursor = ''
  document.body.style.userSelect = ''
}

const startResize = (e) => {
  e.preventDefault()
  e.stopPropagation()

  isResizing.value = true
  dragStartX = e.clientX
  initialDuration = props.note.duration

  document.addEventListener('mousemove', onResize)
  document.addEventListener('mouseup', stopResize)
  document.body.style.cursor = 'ew-resize'
  document.body.style.userSelect = 'none'
}

const onResize = (e) => {
  if (!isResizing.value) return

  const deltaX = e.clientX - dragStartX
  const deltaBeats = uiStore.pixelsToBeats(deltaX)
  let newDuration = initialDuration + deltaBeats

  // Contrainte minimale
  const minDuration = midiStore.snapEnabled ? midiStore.getSnapValue : 0.1
  newDuration = Math.max(minDuration, newDuration)

  // Afficher l'indicateur de snap pour la durée
  if (midiStore.snapEnabled) {
    const snappedDuration = midiStore.snapToGrid(newDuration)
    showSnapIndicator.value = true
    snapIndicatorStyle.value = {
      left: noteStyle.value.left,
      top: noteStyle.value.top,
      width: uiStore.beatsToPixels(snappedDuration) + 'px',
      height: noteStyle.value.height
    }
  }

  // Mettre à jour la durée en temps réel
  midiStore.updateNote(props.note.id, { duration: newDuration })
}

const stopResize = () => {
  if (!isResizing.value) return

  isResizing.value = false
  showSnapIndicator.value = false
  showResizeCursor.value = false

  // Appliquer le snap final pour la durée
  if (midiStore.snapEnabled) {
    const snappedDuration = midiStore.snapToGrid(props.note.duration)
    midiStore.updateNote(props.note.id, { duration: snappedDuration })
  }

  document.removeEventListener('mousemove', onResize)
  document.removeEventListener('mouseup', stopResize)
  document.body.style.cursor = ''
  document.body.style.userSelect = ''
}

// Cleanup au démontage
import { onUnmounted } from 'vue'
onUnmounted(() => {
  document.removeEventListener('mousemove', onDrag)
  document.removeEventListener('mouseup', stopDrag)
  document.removeEventListener('mousemove', onResize)
  document.removeEventListener('mouseup', stopResize)
})
</script>

<style scoped>
.midi-note {
  position: absolute;
  background: #4CAF50;
  border: 1px solid #45a049;
  border-radius: 3px;
  cursor: grab;
  transition: box-shadow 0.2s;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 2px 4px;
  box-sizing: border-box;
  min-width: 20px;
}

.midi-note:hover {
  background: #66BB6A;
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.midi-note.selected {
  background: #2196F3;
  border-color: #1976D2;
  box-shadow: 0 0 8px rgba(33, 150, 243, 0.6);
}

.midi-note.dragging {
  cursor: grabbing;
  z-index: 1000 !important;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

.midi-note.resizing {
  cursor: ew-resize;
}

.note-content {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  pointer-events: none; /* Éviter les conflits avec la zone de resize */
}

.note-name {
  font-size: 10px;
  font-weight: bold;
  color: white;
  text-shadow: 0 1px 2px rgba(0,0,0,0.5);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.note-velocity {
  font-size: 8px;
  color: rgba(255,255,255,0.8);
  text-shadow: 0 1px 2px rgba(0,0,0,0.5);
}

.resize-handle {
  position: absolute;
  right: 0;
  top: 0;
  bottom: 0;
  width: 8px;
  background: rgba(255,255,255,0.2);
  cursor: ew-resize;
  border-radius: 0 2px 2px 0;
  transition: background-color 0.2s, width 0.2s;
}

.resize-handle.resize-hover,
.resize-handle:hover {
  background: rgba(255,255,255,0.4);
  width: 10px;
}

.midi-note.selected .resize-handle {
  background: rgba(255,255,255,0.3);
}

.snap-indicator {
  position: absolute;
  border: 2px dashed #FF9800;
  background: rgba(255, 152, 0, 0.1);
  pointer-events: none;
  border-radius: 3px;
  z-index: 999;
}
</style>
<template>
  <div class="midi-lanes" :style="{ width: totalMeasures * uiStore.pixelsPerMeasure + 'px' }">
    <el-tabs v-model="activeTab" type="card" class="lanes-tabs">
      <el-tab-pane
        v-for="lane in availableLanes"
        :key="lane.id"
        :label="lane.label"
        :name="lane.id"
      >
        <component
          :is="lane.component"
          v-bind="lane.props"
          :total-measures="totalMeasures"
          :visible-measures="visibleMeasures"
          :measure-to-pixels="measureToPixels"
        />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useUIStore } from '@/stores/ui'
import VelocityLane from '@/components/lanes/VelocityLane.vue'
import CCLane from '@/components/lanes/CCLane.vue'

const uiStore = useUIStore()

const totalMeasures = 32
const activeTab = ref('velocity')

const visibleMeasures = computed(() => {
  return Array.from({ length: totalMeasures }, (_, i) => i + 1)
})

const measureToPixels = (measure) => {
  return (measure - 1) * uiStore.pixelsPerMeasure
}

// Configuration des lanes disponibles
const availableLanes = ref([
  {
    id: 'velocity',
    label: 'Velocity',
    component: VelocityLane,
    props: {}
  },
  {
    id: 'cc1',
    label: 'CC1 (Mod)',
    component: CCLane,
    props: { ccNumber: 1, ccName: 'Modulation' }
  },
  {
    id: 'cc7',
    label: 'CC7 (Vol)',
    component: CCLane,
    props: { ccNumber: 7, ccName: 'Volume' }
  }
])

// Méthode pour ajouter dynamiquement une nouvelle lane CC
const addCCLane = (ccNumber, ccName = `CC${ccNumber}`) => {
  const newLane = {
    id: `cc${ccNumber}`,
    label: `CC${ccNumber}${ccName !== `CC${ccNumber}` ? ` (${ccName})` : ''}`,
    component: CCLane,
    props: { ccNumber, ccName }
  }

  if (!availableLanes.value.find(lane => lane.id === newLane.id)) {
    availableLanes.value.push(newLane)
  }
}

// Méthode pour supprimer une lane
const removeLane = (laneId) => {
  const index = availableLanes.value.findIndex(lane => lane.id === laneId)
  if (index > -1 && laneId !== 'velocity') { // Empêcher la suppression de la lane velocity
    availableLanes.value.splice(index, 1)
    if (activeTab.value === laneId) {
      activeTab.value = 'velocity'
    }
  }
}

// Exposer les méthodes pour l'utilisation depuis le parent
defineExpose({
  addCCLane,
  removeLane
})
</script>

<style scoped>
.midi-lanes {
  height: 100%;
  background: #fafafa;
  min-width: 100%;
}

.lanes-tabs {
  height: 100%;
}

:deep(.el-tabs__content) {
  height: calc(100% - 40px);
  padding: 0;
}

:deep(.el-tab-pane) {
  height: 100%;
}

:deep(.el-tabs__header) {
  margin: 0;
}
</style>
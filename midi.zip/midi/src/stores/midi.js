import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useMidiStore = defineStore('midi', () => {
  // Notes MIDI
  const notes = ref([])

  // Pistes MIDI
  const tracks = ref([])

  // Piste sélectionnée
  const selectedTrack = ref(null)

  // Informations du fichier MIDI
  const midiInfo = ref({
    filename: '',
    format: 0,
    ticksPerQuarter: 480,
    bpm: 120,
    timeSignature: { numerator: 4, denominator: 4 },
    keySignature: { key: 0, scale: 0 }
  })

  // Messages MIDI CC
  const midiCC = ref([])

  // Événements de tempo
  const tempoEvents = ref([])

  // Note sélectionnée
  const selectedNote = ref(null)

  // Configuration du snap
  const snapEnabled = ref(true)
  const snapDivisions = {
    whole: 4,      // ronde
    half: 2,       // blanche
    quarter: 1,    // noire
    eighth: 0.5,   // croche
    sixteenth: 0.25, // double croche
    triplet: 1/3   // triolet
  }
  const currentSnapDivision = ref('sixteenth')

  // Getters
  const getSnapValue = computed(() => {
    return snapEnabled.value ? snapDivisions[currentSnapDivision.value] : 0.01
  })

  const getNoteById = computed(() => {
    return (id) => notes.value.find(note => note.id === id)
  })

  const getNotesByTrack = computed(() => {
    return (trackId) => notes.value.filter(note => note.trackId === trackId)
  })

  // Nouvelles computed properties pour la piste sélectionnée
  const getSelectedTrack = computed(() => {
    return selectedTrack.value ? tracks.value.find(track => track.id === selectedTrack.value) : null
  })

  const getSelectedTrackNotes = computed(() => {
    return selectedTrack.value ? notes.value.filter(note => note.trackId === selectedTrack.value) : []
  })

  const getSelectedTrackCC = computed(() => {
    return selectedTrack.value ? midiCC.value.filter(cc => cc.trackId === selectedTrack.value) : []
  })

  const getTrackById = computed(() => {
    return (id) => tracks.value.find(track => track.id === id)
  })

  // Actions pour la piste sélectionnée
  const selectTrack = (trackId) => {
    selectedTrack.value = selectedTrack.value === trackId ? null : trackId
  }

  const clearTrackSelection = () => {
    selectedTrack.value = null
  }

  // Actions existantes
  const selectNote = (noteId) => {
    const note = notes.value.find(n => n.id === noteId)
    selectedNote.value = selectedNote.value?.id === noteId ? null : note
  }

  const updateNote = (noteId, updates) => {
    const noteIndex = notes.value.findIndex(n => n.id === noteId)
    if (noteIndex !== -1) {
      notes.value[noteIndex] = { ...notes.value[noteIndex], ...updates }
    }
  }

  const updateNoteVelocity = (noteId, velocity) => {
    const clampedVelocity = Math.max(1, Math.min(127, Math.round(velocity)))
    updateNote(noteId, { velocity: clampedVelocity })
  }

  const moveNote = (noteId, newStart, newMidi) => {
    updateNote(noteId, {
      start: snapEnabled.value ? snapToGrid(newStart) : newStart,
      midi: Math.max(0, Math.min(127, Math.round(newMidi)))
    })
  }

  const resizeNote = (noteId, newDuration) => {
    const minDuration = getSnapValue.value
    const snappedDuration = snapEnabled.value ?
      Math.max(minDuration, snapToGrid(newDuration)) :
      Math.max(0.1, newDuration)

    updateNote(noteId, { duration: snappedDuration })
  }

  const snapToGrid = (value) => {
    const snapValue = getSnapValue.value
    return Math.round(value / snapValue) * snapValue
  }

  const setSnapEnabled = (enabled) => {
    snapEnabled.value = enabled
  }

  const setSnapDivision = (division) => {
    if (division in snapDivisions) {
      currentSnapDivision.value = division
    }
  }

  const addNote = (note) => {
    const newId = Math.max(...notes.value.map(n => n.id), 0) + 1
    // Si une piste est sélectionnée et que la note n'a pas de trackId, l'assigner à la piste sélectionnée
    const trackId = note.trackId || selectedTrack.value || 1
    notes.value.push({ id: newId, trackId, ...note })
    return newId
  }

  const deleteNote = (noteId) => {
    const index = notes.value.findIndex(n => n.id === noteId)
    if (index !== -1) {
      notes.value.splice(index, 1)
      if (selectedNote.value?.id === noteId) {
        selectedNote.value = null
      }
    }
  }

  const addTrack = (track) => {
    const newId = Math.max(...tracks.value.map(t => t.id), 0) + 1
    const newTrack = {
      id: newId,
      name: track.name || `Piste ${newId}`,
      instrument: track.instrument || 'Unknown',
      program: track.program || 0,
      channel: track.channel || 0,
      volume: track.volume || 100,
      pan: track.pan || 64,
      solo: false,
      mute: false,
      ...track
    }
    tracks.value.push(newTrack)
    return newId
  }

  const updateTrack = (trackId, updates) => {
    const trackIndex = tracks.value.findIndex(t => t.id === trackId)
    if (trackIndex !== -1) {
      tracks.value[trackIndex] = { ...tracks.value[trackIndex], ...updates }
    }
  }

  const deleteTrack = (trackId) => {
    const index = tracks.value.findIndex(t => t.id === trackId)
    if (index !== -1) {
      tracks.value.splice(index, 1)
      // Supprimer aussi les notes de cette piste
      notes.value = notes.value.filter(note => note.trackId !== trackId)
      // Désélectionner la piste si elle était sélectionnée
      if (selectedTrack.value === trackId) {
        selectedTrack.value = null
      }
    }
  }

  // Fonction pour charger un fichier MIDI
  const loadMidiFile = async (arrayBuffer, filename) => {
    try {
      const midiData = parseMidiFile(arrayBuffer)

      // Réinitialiser les données
      notes.value = []
      tracks.value = []
      midiCC.value = []
      tempoEvents.value = []
      selectedTrack.value = null // Réinitialiser la sélection

      // Charger les informations du fichier
      midiInfo.value.filename = filename
      midiInfo.value.format = midiData.format
      midiInfo.value.ticksPerQuarter = midiData.ticksPerQuarter

      let noteId = 1

      // Traiter chaque piste
      midiData.tracks.forEach((trackData, trackIndex) => {
        const trackId = trackIndex + 1
        let trackName = `Piste ${trackId}`
        let instrument = 'Unknown'
        let program = 0
        let channel = 0
        let volume = 100
        let pan = 64

        const trackNotes = []
        const trackCC = []
        let currentTime = 0

        // Traiter les événements de la piste
        trackData.events.forEach(event => {
          currentTime += event.deltaTime

          switch (event.type) {
            case 'trackName':
              trackName = event.text || trackName
              break

            case 'programChange':
              program = event.program
              instrument = getInstrumentName(program)
              channel = event.channel
              break

            case 'controlChange':
              if (event.controller === 7) { // Volume
                volume = event.value
              } else if (event.controller === 10) { // Pan
                pan = event.value
              }
              trackCC.push({
                id: midiCC.value.length + trackCC.length + 1,
                trackId,
                time: ticksToBeats(currentTime, midiInfo.value.ticksPerQuarter),
                controller: event.controller,
                value: event.value,
                channel: event.channel
              })
              break

            case 'noteOn':
              if (event.velocity > 0) {
                trackNotes.push({
                  id: noteId++,
                  trackId,
                  midi: event.noteNumber,
                  start: ticksToBeats(currentTime, midiInfo.value.ticksPerQuarter),
                  velocity: event.velocity,
                  channel: event.channel,
                  startTime: currentTime
                })
              }
              break

            case 'noteOff':
              // Trouver la note correspondante et calculer la durée
              const noteIndex = trackNotes.findIndex(note =>
                note.midi === event.noteNumber &&
                note.channel === event.channel &&
                !note.duration
              )
              if (noteIndex !== -1) {
                const note = trackNotes[noteIndex]
                note.duration = ticksToBeats(currentTime - note.startTime, midiInfo.value.ticksPerQuarter)
                delete note.startTime // Nettoyer la propriété temporaire
              }
              break

            case 'setTempo':
              tempoEvents.value.push({
                time: ticksToBeats(currentTime, midiInfo.value.ticksPerQuarter),
                bpm: 60000000 / event.microsecondsPerBeat
              })
              break

            case 'timeSignature':
              midiInfo.value.timeSignature = {
                numerator: event.numerator,
                denominator: Math.pow(2, event.denominator)
              }
              break

            case 'keySignature':
              midiInfo.value.keySignature = {
                key: event.key,
                scale: event.scale
              }
              break
          }
        })

        // Ajouter la piste si elle contient des notes ou des événements intéressants
        if (trackNotes.length > 0 || trackCC.length > 0 || trackName !== `Piste ${trackId}`) {
          addTrack({
            name: trackName,
            instrument,
            program,
            channel,
            volume,
            pan
          })

          // Ajouter les notes valides (avec durée)
          trackNotes.forEach(note => {
            if (note.duration && note.duration > 0) {
              notes.value.push(note)
            }
          })

          // Ajouter les événements CC
          midiCC.value.push(...trackCC)
        }
      })

      // Définir le BPM initial si on a des événements de tempo
      if (tempoEvents.value.length > 0) {
        midiInfo.value.bpm = tempoEvents.value[0].bpm
      }

      // Sélectionner automatiquement la première piste si elle existe
      if (tracks.value.length > 0) {
        selectedTrack.value = tracks.value[0].id
      }

      console.log('Fichier MIDI chargé:', {
        filename,
        tracks: tracks.value.length,
        notes: notes.value.length,
        ccEvents: midiCC.value.length,
        tempoEvents: tempoEvents.value.length,
        selectedTrack: selectedTrack.value
      })

    } catch (error) {
      console.error('Erreur lors du parsing du fichier MIDI:', error)
      throw new Error('Impossible de lire le fichier MIDI')
    }
  }

  // Fonction utilitaire pour convertir les ticks en beats
  const ticksToBeats = (ticks, ticksPerQuarter) => {
    return ticks / ticksPerQuarter
  }

  // Fonction pour obtenir le nom de l'instrument à partir du numéro de programme
  const getInstrumentName = (program) => {
    const instruments = [
      'Acoustic Grand Piano', 'Bright Acoustic Piano', 'Electric Grand Piano', 'Honky-tonk Piano',
      'Electric Piano 1', 'Electric Piano 2', 'Harpsichord', 'Clavi',
      'Celesta', 'Glockenspiel', 'Music Box', 'Vibraphone',
      'Marimba', 'Xylophone', 'Tubular Bells', 'Dulcimer',
      'Drawbar Organ', 'Percussive Organ', 'Rock Organ', 'Church Organ',
      'Reed Organ', 'Accordion', 'Harmonica', 'Tango Accordion',
      'Acoustic Guitar (nylon)', 'Acoustic Guitar (steel)', 'Electric Guitar (jazz)', 'Electric Guitar (clean)',
      'Electric Guitar (muted)', 'Overdriven Guitar', 'Distortion Guitar', 'Guitar harmonics',
      'Acoustic Bass', 'Electric Bass (finger)', 'Electric Bass (pick)', 'Fretless Bass',
      'Slap Bass 1', 'Slap Bass 2', 'Synth Bass 1', 'Synth Bass 2',
      'Violin', 'Viola', 'Cello', 'Contrabass',
      'Tremolo Strings', 'Pizzicato Strings', 'Orchestral Harp', 'Timpani',
      'String Ensemble 1', 'String Ensemble 2', 'SynthStrings 1', 'SynthStrings 2',
      'Choir Aahs', 'Voice Oohs', 'Synth Voice', 'Orchestra Hit',
      'Trumpet', 'Trombone', 'Tuba', 'Muted Trumpet',
      'French Horn', 'Brass Section', 'SynthBrass 1', 'SynthBrass 2',
      'Soprano Sax', 'Alto Sax', 'Tenor Sax', 'Baritone Sax',
      'Oboe', 'English Horn', 'Bassoon', 'Clarinet',
      'Piccolo', 'Flute', 'Recorder', 'Pan Flute',
      'Blown Bottle', 'Shakuhachi', 'Whistle', 'Ocarina',
      'Lead 1 (square)', 'Lead 2 (sawtooth)', 'Lead 3 (calliope)', 'Lead 4 (chiff)',
      'Lead 5 (charang)', 'Lead 6 (voice)', 'Lead 7 (fifths)', 'Lead 8 (bass + lead)',
      'Pad 1 (new age)', 'Pad 2 (warm)', 'Pad 3 (polysynth)', 'Pad 4 (choir)',
      'Pad 5 (bowed)', 'Pad 6 (metallic)', 'Pad 7 (halo)', 'Pad 8 (sweep)',
      'FX 1 (rain)', 'FX 2 (soundtrack)', 'FX 3 (crystal)', 'FX 4 (atmosphere)',
      'FX 5 (brightness)', 'FX 6 (goblins)', 'FX 7 (echoes)', 'FX 8 (sci-fi)',
      'Sitar', 'Banjo', 'Shamisen', 'Koto',
      'Kalimba', 'Bag pipe', 'Fiddle', 'Shanai',
      'Tinkle Bell', 'Agogo', 'Steel Drums', 'Woodblock',
      'Taiko Drum', 'Melodic Tom', 'Synth Drum', 'Reverse Cymbal',
      'Guitar Fret Noise', 'Breath Noise', 'Seashore', 'Bird Tweet',
      'Telephone Ring', 'Helicopter', 'Applause', 'Gunshot'
    ]
    return instruments[program] || `Program ${program}`
  }

  // Parser MIDI simple (version basique) - Code identique au précédent
  const parseMidiFile = (arrayBuffer) => {
    const dataView = new DataView(arrayBuffer)
    let offset = 0

    // Lire l'en-tête
    const headerChunk = readChunk(dataView, offset)
    offset += 8 + headerChunk.length

    if (headerChunk.type !== 'MThd') {
      throw new Error('Format de fichier MIDI invalide')
    }

    const format = dataView.getUint16(8)
    const trackCount = dataView.getUint16(10)
    const ticksPerQuarter = dataView.getUint16(12)

    const tracks = []

    // Lire les pistes
    for (let i = 0; i < trackCount; i++) {
      const trackChunk = readChunk(dataView, offset)
      offset += 8

      if (trackChunk.type === 'MTrk') {
        const trackData = parseTrack(dataView, offset, trackChunk.length)
        tracks.push(trackData)
      }

      offset += trackChunk.length
    }

    return {
      format,
      trackCount,
      ticksPerQuarter,
      tracks
    }
  }

  const readChunk = (dataView, offset) => {
    const type = String.fromCharCode(
      dataView.getUint8(offset),
      dataView.getUint8(offset + 1),
      dataView.getUint8(offset + 2),
      dataView.getUint8(offset + 3)
    )
    const length = dataView.getUint32(offset + 4)
    return { type, length }
  }

  const parseTrack = (dataView, offset, length) => {
    const events = []
    const endOffset = offset + length
    let runningStatus = 0

    while (offset < endOffset) {
      const deltaTime = readVariableLength(dataView, offset)
      offset += deltaTime.bytesRead

      let status = dataView.getUint8(offset)

      // Running status
      if (status < 0x80) {
        status = runningStatus
        offset-- // Reculer car on n'a pas lu un nouveau status
      } else {
        runningStatus = status
      }
      offset++

      const event = { deltaTime: deltaTime.value }

      if (status >= 0x80 && status <= 0xEF) {
        // Messages de canal
        const channel = status & 0x0F
        const messageType = (status & 0xF0) >> 4

        switch (messageType) {
          case 0x8: // Note Off
            event.type = 'noteOff'
            event.channel = channel
            event.noteNumber = dataView.getUint8(offset++)
            event.velocity = dataView.getUint8(offset++)
            break

          case 0x9: // Note On
            event.type = 'noteOn'
            event.channel = channel
            event.noteNumber = dataView.getUint8(offset++)
            event.velocity = dataView.getUint8(offset++)
            break

          case 0xB: // Control Change
            event.type = 'controlChange'
            event.channel = channel
            event.controller = dataView.getUint8(offset++)
            event.value = dataView.getUint8(offset++)
            break

          case 0xC: // Program Change
            event.type = 'programChange'
            event.channel = channel
            event.program = dataView.getUint8(offset++)
            break

          default:
            // Ignorer les autres types pour simplifier
            offset += 2
            continue
        }
      } else if (status === 0xFF) {
        // Meta events
        const metaType = dataView.getUint8(offset++)
        const metaLength = readVariableLength(dataView, offset)
        offset += metaLength.bytesRead

        switch (metaType) {
          case 0x03: // Track Name
            event.type = 'trackName'
            event.text = readString(dataView, offset, metaLength.value)
            break

          case 0x51: // Set Tempo
            event.type = 'setTempo'
            event.microsecondsPerBeat = (dataView.getUint8(offset) << 16) |
                                      (dataView.getUint8(offset + 1) << 8) |
                                      dataView.getUint8(offset + 2)
            break

          case 0x58: // Time Signature
            event.type = 'timeSignature'
            event.numerator = dataView.getUint8(offset)
            event.denominator = dataView.getUint8(offset + 1)
            event.clocksPerTick = dataView.getUint8(offset + 2)
            event.thirtySecondNotesPerQuarter = dataView.getUint8(offset + 3)
            break

          case 0x59: // Key Signature
            event.type = 'keySignature'
            event.key = dataView.getInt8(offset)
            event.scale = dataView.getUint8(offset + 1)
            break
        }

        offset += metaLength.value
      } else {
        // Ignorer les autres événements
        continue
      }

      events.push(event)
    }

    return { events }
  }

  const readVariableLength = (dataView, offset) => {
    let value = 0
    let bytesRead = 0
    let byte

    do {
      byte = dataView.getUint8(offset + bytesRead)
      value = (value << 7) | (byte & 0x7F)
      bytesRead++
    } while (byte & 0x80)

    return { value, bytesRead }
  }

  const readString = (dataView, offset, length) => {
    let str = ''
    for (let i = 0; i < length; i++) {
      str += String.fromCharCode(dataView.getUint8(offset + i))
    }
    return str
  }

  return {
    // State
    notes,
    tracks,
    selectedTrack,
    midiInfo,
    midiCC,
    tempoEvents,
    selectedNote,
    snapEnabled,
    currentSnapDivision,
    snapDivisions,

    // Getters
    getSnapValue,
    getNoteById,
    getNotesByTrack,
    getSelectedTrack,
    getSelectedTrackNotes,
    getSelectedTrackCC,
    getTrackById,

    // Actions
    selectTrack,
    clearTrackSelection,
    selectNote,
    updateNote,
    updateNoteVelocity,
    moveNote,
    resizeNote,
    snapToGrid,
    setSnapEnabled,
    setSnapDivision,
    addNote,
    deleteNote,
    addTrack,
    updateTrack,
    deleteTrack,
    loadMidiFile
  }
})
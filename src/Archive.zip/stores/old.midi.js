import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useMidiStore = defineStore('midi', () => {
  // Notes MIDI
  const notes = ref([])

  // Pistes MIDI
  const tracks = ref([])

  // Piste sélectionnée
  const selectedTrack = ref(null)

  // Informations du fichier MIDI
  const midiInfo = ref({
    filename: '',
    format: 0,
    ticksPerQuarter: 480,
    bpm: 120,
    timeSignature: { numerator: 4, denominator: 4 },
    keySignature: { key: 0, scale: 0 }
  })

  // Messages MIDI CC
  const midiCC = ref([])

  // Événements de tempo
  const tempoEvents = ref([])

  const timeSignatureEvents = ref([])
  const keySignatureEvents = ref([])

  // Note sélectionnée
  const selectedNote = ref(null)

  // Configuration du snap
  const snapEnabled = ref(true)
  const snapDivisions = {
    whole: 4,      // ronde
    half: 2,       // blanche
    quarter: 1,    // noire
    eighth: 0.5,   // croche
    sixteenth: 0.25, // double croche
    triplet: 1/3   // triolet
  }
  const currentSnapDivision = ref('sixteenth')

  // Getters
  const getSnapValue = computed(() => {
    return snapEnabled.value ? snapDivisions[currentSnapDivision.value] : 0.01
  })

  const getNoteById = computed(() => {
    return (id) => notes.value.find(note => note.id === id)
  })

  const getNotesByTrack = computed(() => {
    return (trackId) => notes.value.filter(note => note.trackId === trackId)
  })

  // Nouvelles computed properties pour la piste sélectionnée
  const getSelectedTrack = computed(() => {
    return selectedTrack.value ? tracks.value.find(track => track.id === selectedTrack.value) : null
  })

  const getSelectedTrackNotes = computed(() => {
    return selectedTrack.value ? notes.value.filter(note => note.trackId === selectedTrack.value) : []
  })

  const getSelectedTrackCC = computed(() => {
    return selectedTrack.value ? midiCC.value.filter(cc => cc.trackId === selectedTrack.value) : []
  })

  const getTrackById = computed(() => {
    return (id) => tracks.value.find(track => track.id === id)
  })

  const getTimeSignatureAtTime = computed(() => {
    return (time) => {
      // Trouve la signature rythmique active au temps donné
      const activeSignatures = timeSignatureEvents.value
        .filter(sig => sig.time <= time)
        .sort((a, b) => b.time - a.time)
      
      return activeSignatures.length > 0 ? activeSignatures[0] : midiInfo.value.timeSignature
    }
  })

  const getTimeSignatureChanges = computed(() => {
    // Retourne tous les changements de signature rythmique triés par temps
    return timeSignatureEvents.value.slice().sort((a, b) => a.time - b.time)
  })  

  // Actions pour la piste sélectionnée
  const selectTrack = (trackId) => {
    selectedTrack.value = selectedTrack.value === trackId ? null : trackId
  }

  const clearTrackSelection = () => {
    selectedTrack.value = null
  }

  // Actions existantes
  const selectNote = (noteId) => {
    const note = notes.value.find(n => n.id === noteId)
    selectedNote.value = selectedNote.value?.id === noteId ? null : note
  }

  const updateNote = (noteId, updates) => {
    const noteIndex = notes.value.findIndex(n => n.id === noteId)
    if (noteIndex !== -1) {
      notes.value[noteIndex] = { ...notes.value[noteIndex], ...updates }
    }
  }

  const updateNoteVelocity = (noteId, velocity) => {
    const clampedVelocity = Math.max(1, Math.min(127, Math.round(velocity)))
    updateNote(noteId, { velocity: clampedVelocity })
  }

  const moveNote = (noteId, newStart, newMidi) => {
    updateNote(noteId, {
      start: snapEnabled.value ? snapToGrid(newStart) : newStart,
      midi: Math.max(0, Math.min(127, Math.round(newMidi)))
    })
  }

  const resizeNote = (noteId, newDuration) => {
    const minDuration = getSnapValue.value
    const snappedDuration = snapEnabled.value ?
      Math.max(minDuration, snapToGrid(newDuration)) :
      Math.max(0.1, newDuration)

    updateNote(noteId, { duration: snappedDuration })
  }

  const snapToGrid = (value) => {
    const snapValue = getSnapValue.value
    return Math.round(value / snapValue) * snapValue
  }

  const setSnapEnabled = (enabled) => {
    snapEnabled.value = enabled
  }

  const setSnapDivision = (division) => {
    if (division in snapDivisions) {
      currentSnapDivision.value = division
    }
  }

  const addNote = (note) => {
    const newId = Math.max(...notes.value.map(n => n.id), 0) + 1
    // Si une piste est sélectionnée et que la note n'a pas de trackId, l'assigner à la piste sélectionnée
    const trackId = note.trackId || selectedTrack.value || 1
    notes.value.push({ id: newId, trackId, ...note })
    return newId
  }

  const deleteNote = (noteId) => {
    const index = notes.value.findIndex(n => n.id === noteId)
    if (index !== -1) {
      notes.value.splice(index, 1)
      if (selectedNote.value?.id === noteId) {
        selectedNote.value = null
      }
    }
  }

  const addTrack = (track) => {
    const newId = Math.max(...tracks.value.map(t => t.id), 0) + 1
    const newTrack = {
      id: newId,
      name: track.name || `Piste ${newId}`,
      instrument: track.instrument || 'Unknown',
      program: track.program || 0,
      channel: track.channel || 0,
      volume: track.volume || 100,
      pan: track.pan || 64,
      solo: false,
      mute: false,
      ...track
    }
    tracks.value.push(newTrack)
    return newId
  }

  const updateTrack = (trackId, updates) => {
    const trackIndex = tracks.value.findIndex(t => t.id === trackId)
    if (trackIndex !== -1) {
      tracks.value[trackIndex] = { ...tracks.value[trackIndex], ...updates }
    }
  }

  const deleteTrack = (trackId) => {
    const index = tracks.value.findIndex(t => t.id === trackId)
    if (index !== -1) {
      tracks.value.splice(index, 1)
      // Supprimer aussi les notes de cette piste
      notes.value = notes.value.filter(note => note.trackId !== trackId)
      // Désélectionner la piste si elle était sélectionnée
      if (selectedTrack.value === trackId) {
        selectedTrack.value = null
      }
    }
  }

// Fonction pour charger un fichier MIDI - VERSION CORRIGÉE AVEC DEBUG
const loadMidiFile = async (arrayBuffer, filename) => {
  try {
    console.log('=== DÉBUT CHARGEMENT MIDI ===')
    console.log(`Fichier: ${filename}, Taille: ${arrayBuffer.byteLength} bytes`)
    
    // D'abord faire une analyse de debug
    debugMidiFile(arrayBuffer)
    
    const midiData = parseMidiFile(arrayBuffer)
    console.log('Données MIDI parsées:', midiData)
    
    // Réinitialiser les données
    notes.value = []
    tracks.value = []
    midiCC.value = []
    tempoEvents.value = []
    timeSignatureEvents.value = []
    keySignatureEvents.value = []
    selectedTrack.value = null

    // Charger les informations du fichier
    midiInfo.value.filename = filename
    midiInfo.value.format = midiData.format
    midiInfo.value.ticksPerQuarter = midiData.ticksPerQuarter

    let noteId = 1

    console.log('=== PHASE 1: EXTRACTION DES SIGNATURES RYTHMIQUES ===')
    
    // CORRECTION 1: Parcourir toutes les tracks pour extraire TOUS les événements de signature
    // avec un calcul de temps absolu correct
    midiData.tracks.forEach((trackData, trackIndex) => {
      let absoluteTime = 0 // Temps absolu en ticks pour cette track
      console.log(`Analyse des signatures dans piste ${trackIndex}:`, trackData.events.length, 'événements')
      
      trackData.events.forEach((event, eventIndex) => {
        // CORRECTION 2: Accumuler le temps absolu correctement
        absoluteTime += event.deltaTime
        
        if (event.type === 'timeSignature') {
          const timeInBeats = ticksToBeats(absoluteTime, midiInfo.value.ticksPerQuarter)
          const timeSignatureEvent = {
            time: timeInBeats,
            absoluteTicks: absoluteTime, // Garder aussi le temps en ticks pour debug
            numerator: event.numerator,
            denominator: Math.pow(2, event.denominator), // CORRECTION 3: Conversion correcte
            clocksPerTick: event.clocksPerTick || 24,
            thirtySecondNotesPerQuarter: event.thirtySecondNotesPerQuarter || 8,
            trackId: trackIndex,
            eventIndex: eventIndex
          }
          
          timeSignatureEvents.value.push(timeSignatureEvent)
          
          console.log(`🎵 SIGNATURE TROUVÉE piste ${trackIndex}: ${timeSignatureEvent.numerator}/${timeSignatureEvent.denominator} au temps ${timeInBeats} beats (ticks: ${absoluteTime})`)
        }
      })
    })
    
    // CORRECTION 4: Trier par temps absolu ET éliminer les vrais doublons
    timeSignatureEvents.value.sort((a, b) => a.time - b.time)
    
    // CORRECTION 5: Améliorer la détection des doublons avec une tolérance plus fine
    const uniqueSignatures = []
    const TOLERANCE = 0.001 // Tolérance très fine pour les temps
    
    timeSignatureEvents.value.forEach(sig => {
      const existing = uniqueSignatures.find(existing => 
        Math.abs(existing.time - sig.time) < TOLERANCE && 
        existing.numerator === sig.numerator && 
        existing.denominator === sig.denominator
      )
      
      if (!existing) {
        uniqueSignatures.push(sig)
        console.log(`✅ Signature unique ajoutée: ${sig.numerator}/${sig.denominator} au temps ${sig.time} beats`)
      } else {
        console.log(`⚠️ Signature en doublon ignorée: ${sig.numerator}/${sig.denominator} au temps ${sig.time} (diff: ${Math.abs(existing.time - sig.time)})`)
      }
    })
    
    timeSignatureEvents.value = uniqueSignatures
    
    console.log(`=== SIGNATURES EXTRAITES: ${timeSignatureEvents.value.length} ===`)
    timeSignatureEvents.value.forEach((sig, index) => {
      console.log(`${index + 1}: ${sig.numerator}/${sig.denominator} au temps ${sig.time} beats (${sig.absoluteTicks} ticks) - piste ${sig.trackId}`)
    })

    // CORRECTION 6: Gestion améliorée de la signature par défaut
    if (timeSignatureEvents.value.length === 0) {
      console.log('🎵 AUCUNE SIGNATURE TROUVÉE - Ajout de 4/4 par défaut au temps 0')
      const defaultSignature = {
        time: 0,
        absoluteTicks: 0,
        numerator: 4,
        denominator: 4,
        clocksPerTick: 24,
        thirtySecondNotesPerQuarter: 8,
        trackId: -1, // Indique une signature par défaut
        eventIndex: -1
      }
      timeSignatureEvents.value.push(defaultSignature)
      midiInfo.value.timeSignature = { numerator: 4, denominator: 4 }
    } else {
      // Utiliser la première signature comme signature globale par défaut
      const firstSig = timeSignatureEvents.value[0]
      midiInfo.value.timeSignature = {
        numerator: firstSig.numerator,
        denominator: firstSig.denominator
      }
      console.log(`🎵 Signature globale définie: ${firstSig.numerator}/${firstSig.denominator}`)
    }

    console.log('=== PHASE 2: TRAITEMENT DES PISTES ===')

    // Le reste du traitement des pistes reste identique
    midiData.tracks.forEach((trackData, trackIndex) => {
      const trackId = trackIndex + 1
      let trackName = `Piste ${trackId}`
      let instrument = 'Unknown'
      let program = 0
      let channel = 0
      let volume = 100
      let pan = 64

      const trackNotes = []
      const trackCC = []
      const trackMetaEvents = []
      const activeNotes = new Map()
      let currentTime = 0

      console.log(`Traitement piste ${trackIndex}:`, trackData.events.length, 'événements')

      // Traiter les événements de la piste (sans retraiter timeSignature)
      trackData.events.forEach((event, eventIndex) => {
        currentTime += event.deltaTime
        
        switch (event.type) {
          case 'trackName':
            trackName = event.text || trackName
            console.log(`Nom de piste trouvé: ${trackName}`)
            break

          case 'programChange':
            program = event.program
            instrument = getInstrumentName(program)
            channel = event.channel
            console.log(`Program change: ${program} (${instrument}) sur canal ${channel}`)
            break

          case 'controlChange':
            if (event.controller === 7) { // Volume
              volume = event.value
            } else if (event.controller === 10) { // Pan
              pan = event.value
            }
            trackCC.push({
              id: midiCC.value.length + trackCC.length + 1,
              trackId,
              time: ticksToBeats(currentTime, midiInfo.value.ticksPerQuarter),
              controller: event.controller,
              value: event.value,
              channel: event.channel
            })
            break

          case 'noteOn':
            if (event.velocity === 0) {
              const noteKey = `${event.channel}-${event.noteNumber}`
              const activeNote = activeNotes.get(noteKey)
              if (activeNote) {
                activeNote.duration = ticksToBeats(currentTime - activeNote.startTime, midiInfo.value.ticksPerQuarter)
                delete activeNote.startTime
                activeNotes.delete(noteKey)
              }
            } else {
              const noteKey = `${event.channel}-${event.noteNumber}`
              const newNote = {
                id: noteId++,
                trackId,
                midi: event.noteNumber,
                start: ticksToBeats(currentTime, midiInfo.value.ticksPerQuarter),
                velocity: event.velocity,
                channel: event.channel,
                startTime: currentTime
              }
              
              const existingNote = activeNotes.get(noteKey)
              if (existingNote) {
                existingNote.duration = ticksToBeats(currentTime - existingNote.startTime, midiInfo.value.ticksPerQuarter)
                delete existingNote.startTime
              }
              
              activeNotes.set(noteKey, newNote)
              trackNotes.push(newNote)
            }
            break

          case 'noteOff':
            const noteKey = `${event.channel}-${event.noteNumber}`
            const activeNote = activeNotes.get(noteKey)
            if (activeNote) {
              activeNote.duration = ticksToBeats(currentTime - activeNote.startTime, midiInfo.value.ticksPerQuarter)
              delete activeNote.startTime
              activeNotes.delete(noteKey)
            }
            break

          case 'setTempo':
            const tempoEvent = {
              time: ticksToBeats(currentTime, midiInfo.value.ticksPerQuarter),
              bpm: 60000000 / event.microsecondsPerBeat
            }
            tempoEvents.value.push(tempoEvent)
            trackMetaEvents.push({ type: 'tempo', ...tempoEvent })
            break

          case 'keySignature':
            const keySignatureEvent = {
              time: ticksToBeats(currentTime, midiInfo.value.ticksPerQuarter),
              key: event.key,
              scale: event.scale,
              trackId: trackId
            }
            midiInfo.value.keySignature = {
              key: event.key,
              scale: event.scale
            }
            keySignatureEvents.value.push(keySignatureEvent)
            trackMetaEvents.push({ type: 'keySignature', ...keySignatureEvent })
            break

          // CORRECTION 7: Ne plus traiter timeSignature ici car déjà fait en phase 1
          case 'timeSignature':
            // Ignoré - déjà traité en phase 1
            break
        }
      })

      // Terminer les notes actives restantes
      activeNotes.forEach((note, key) => {
        note.duration = 1.0
        delete note.startTime
      })

      // Logique pour ajouter les pistes jouables (inchangée)
      const hasNotes = trackNotes.length > 0
      const hasCC = trackCC.length > 0
      const hasInstrumentData = program !== 0 || instrument !== 'Unknown'
      const hasCustomName = trackName !== `Piste ${trackId}` && trackName.trim() !== ''
      
      const isPlayableTrack = hasNotes || hasCC || hasInstrumentData
      const isMetadataOnlyTrack = !hasNotes && !hasCC && !hasInstrumentData && trackMetaEvents.length > 0
      
      if (isPlayableTrack) {
        const newTrackId = addTrack({
          name: hasCustomName ? trackName : `${instrument}`,
          instrument,
          program,
          channel,
          volume,
          pan
        })

        trackNotes.forEach(note => {
          note.trackId = newTrackId
          if (note.duration && note.duration > 0) {
            notes.value.push(note)
          }
        })

        trackCC.forEach(cc => {
          cc.trackId = newTrackId
        })
        midiCC.value.push(...trackCC)

        console.log(`✅ Piste AJOUTÉE: "${hasCustomName ? trackName : instrument}"`)
      }
    })

    // Définir le BPM initial
    if (tempoEvents.value.length > 0) {
      midiInfo.value.bpm = tempoEvents.value[0].bpm
    }

    // Sélectionner automatiquement la première piste
    if (tracks.value.length > 0) {
      selectedTrack.value = tracks.value[0].id
    }

    console.log('=== RÉSULTAT FINAL ===')
    console.log(`✅ ${timeSignatureEvents.value.length} signature(s) rythmique(s) chargée(s):`)
    timeSignatureEvents.value.forEach((sig, index) => {
      console.log(`  ${index + 1}: ${sig.numerator}/${sig.denominator} au temps ${sig.time} beats`)
    })
    
    console.log('Fichier MIDI chargé:', {
      filename,
      tracks: tracks.value.length,
      notes: notes.value.length,
      ccEvents: midiCC.value.length,
      tempoEvents: tempoEvents.value.length,
      timeSignatureEvents: timeSignatureEvents.value.length,
      keySignatureEvents: keySignatureEvents.value.length
    })

    // CORRECTION 8: Validation finale
    if (timeSignatureEvents.value.length === 0) {
      console.error('🚨 ERREUR: AUCUNE SIGNATURE RYTHMIQUE APRÈS CHARGEMENT!')
      throw new Error('Aucune signature rythmique détectée')
    }

    if (notes.value.length === 0) {
      console.warn('⚠️ ATTENTION: Aucune note chargée dans le fichier MIDI')
    }

  } catch (error) {
    console.error('Erreur lors du parsing du fichier MIDI:', error)
    throw new Error('Impossible de lire le fichier MIDI: ' + error.message)
  }
}

  // Fonction utilitaire pour convertir les ticks en beats
  const ticksToBeats = (ticks, ticksPerQuarter) => {
    return ticks / ticksPerQuarter
  }

  // Fonction pour obtenir le nom de l'instrument à partir du numéro de programme
  const getInstrumentName = (program) => {
    const instruments = [
      'Acoustic Grand Piano', 'Bright Acoustic Piano', 'Electric Grand Piano', 'Honky-tonk Piano',
      'Electric Piano 1', 'Electric Piano 2', 'Harpsichord', 'Clavi',
      'Celesta', 'Glockenspiel', 'Music Box', 'Vibraphone',
      'Marimba', 'Xylophone', 'Tubular Bells', 'Dulcimer',
      'Drawbar Organ', 'Percussive Organ', 'Rock Organ', 'Church Organ',
      'Reed Organ', 'Accordion', 'Harmonica', 'Tango Accordion',
      'Acoustic Guitar (nylon)', 'Acoustic Guitar (steel)', 'Electric Guitar (jazz)', 'Electric Guitar (clean)',
      'Electric Guitar (muted)', 'Overdriven Guitar', 'Distortion Guitar', 'Guitar harmonics',
      'Acoustic Bass', 'Electric Bass (finger)', 'Electric Bass (pick)', 'Fretless Bass',
      'Slap Bass 1', 'Slap Bass 2', 'Synth Bass 1', 'Synth Bass 2',
      'Violin', 'Viola', 'Cello', 'Contrabass',
      'Tremolo Strings', 'Pizzicato Strings', 'Orchestral Harp', 'Timpani',
      'String Ensemble 1', 'String Ensemble 2', 'SynthStrings 1', 'SynthStrings 2',
      'Choir Aahs', 'Voice Oohs', 'Synth Voice', 'Orchestra Hit',
      'Trumpet', 'Trombone', 'Tuba', 'Muted Trumpet',
      'French Horn', 'Brass Section', 'SynthBrass 1', 'SynthBrass 2',
      'Soprano Sax', 'Alto Sax', 'Tenor Sax', 'Baritone Sax',
      'Oboe', 'English Horn', 'Bassoon', 'Clarinet',
      'Piccolo', 'Flute', 'Recorder', 'Pan Flute',
      'Blown Bottle', 'Shakuhachi', 'Whistle', 'Ocarina',
      'Lead 1 (square)', 'Lead 2 (sawtooth)', 'Lead 3 (calliope)', 'Lead 4 (chiff)',
      'Lead 5 (charang)', 'Lead 6 (voice)', 'Lead 7 (fifths)', 'Lead 8 (bass + lead)',
      'Pad 1 (new age)', 'Pad 2 (warm)', 'Pad 3 (polysynth)', 'Pad 4 (choir)',
      'Pad 5 (bowed)', 'Pad 6 (metallic)', 'Pad 7 (halo)', 'Pad 8 (sweep)',
      'FX 1 (rain)', 'FX 2 (soundtrack)', 'FX 3 (crystal)', 'FX 4 (atmosphere)',
      'FX 5 (brightness)', 'FX 6 (goblins)', 'FX 7 (echoes)', 'FX 8 (sci-fi)',
      'Sitar', 'Banjo', 'Shamisen', 'Koto',
      'Kalimba', 'Bag pipe', 'Fiddle', 'Shanai',
      'Tinkle Bell', 'Agogo', 'Steel Drums', 'Woodblock',
      'Taiko Drum', 'Melodic Tom', 'Synth Drum', 'Reverse Cymbal',
      'Guitar Fret Noise', 'Breath Noise', 'Seashore', 'Bird Tweet',
      'Telephone Ring', 'Helicopter', 'Applause', 'Gunshot'
    ]
    return instruments[program] || `Program ${program}`
  }

// Parser MIDI corrigé avec debug détaillé - SANS RÉFÉRENCES arrayBuffer
const parseMidiFile = (buffer) => {
  const dataView = new DataView(buffer)
  let offset = 0

  // Lire l'en-tête
  const headerChunk = readChunk(dataView, offset)
  offset += 8 + headerChunk.length

  if (headerChunk.type !== 'MThd') {
    throw new Error('Format de fichier MIDI invalide')
  }

  const format = dataView.getUint16(8)
  const trackCount = dataView.getUint16(10)
  const ticksPerQuarter = dataView.getUint16(12)

  console.log(`=== EN-TÊTE MIDI ===`)
  console.log(`Format: ${format}, Tracks: ${trackCount}, Ticks/Quarter: ${ticksPerQuarter}`)

  const tracks = []

  // Lire les pistes
  for (let i = 0; i < trackCount; i++) {
    console.log(`\n=== PARSING TRACK ${i} ===`)
    const trackChunk = readChunk(dataView, offset)
    offset += 8

    if (trackChunk.type === 'MTrk') {
      console.log(`Track ${i}: Type=${trackChunk.type}, Length=${trackChunk.length} bytes`)
      const trackData = parseTrack(dataView, offset, trackChunk.length, i)
      tracks.push(trackData)
      console.log(`Track ${i} parsée: ${trackData.events.length} événements`)
    } else {
      console.warn(`Track ${i}: Type inattendu ${trackChunk.type}, ignorée`)
    }

    offset += trackChunk.length
  }

  return {
    format,
    trackCount,
    ticksPerQuarter,
    tracks
  }
}

const parseTrack = (dataView, offset, length, trackIndex) => {
  const events = []
  const endOffset = offset + length
  let runningStatus = 0
  let currentTime = 0

  console.log(`  Parsing track ${trackIndex} de ${offset} à ${endOffset} (${length} bytes)`)

  while (offset < endOffset) {
    const deltaTime = readVariableLength(dataView, offset)
    offset += deltaTime.bytesRead
    currentTime += deltaTime.value

    if (offset >= endOffset) {
      console.log(`  Fin de track atteinte à offset ${offset}`)
      break
    }

    let status = dataView.getUint8(offset)

    // Running status
    if (status < 0x80) {
      status = runningStatus
      offset-- // Reculer car on n'a pas lu un nouveau status
    } else {
      runningStatus = status
    }
    offset++

    const event = { deltaTime: deltaTime.value }

    if (status >= 0x80 && status <= 0xEF) {
      // Messages de canal
      const channel = status & 0x0F
      const messageType = (status & 0xF0) >> 4

      switch (messageType) {
        case 0x8: // Note Off
          event.type = 'noteOff'
          event.channel = channel
          event.noteNumber = dataView.getUint8(offset++)
          event.velocity = dataView.getUint8(offset++)
          break

        case 0x9: // Note On
          event.type = 'noteOn'
          event.channel = channel
          event.noteNumber = dataView.getUint8(offset++)
          event.velocity = dataView.getUint8(offset++)
          break

        case 0xB: // Control Change
          event.type = 'controlChange'
          event.channel = channel
          event.controller = dataView.getUint8(offset++)
          event.value = dataView.getUint8(offset++)
          break

        case 0xC: // Program Change
          event.type = 'programChange'
          event.channel = channel
          event.program = dataView.getUint8(offset++)
          break

        case 0xA: // Aftertouch
          event.type = 'aftertouch'
          event.channel = channel
          event.noteNumber = dataView.getUint8(offset++)
          event.pressure = dataView.getUint8(offset++)
          break

        case 0xD: // Channel Pressure
          event.type = 'channelPressure'
          event.channel = channel
          event.pressure = dataView.getUint8(offset++)
          break

        case 0xE: // Pitch Bend
          event.type = 'pitchBend'
          event.channel = channel
          const lsb = dataView.getUint8(offset++)
          const msb = dataView.getUint8(offset++)
          event.value = (msb << 7) | lsb
          break

        default:
          console.warn(`  Message de canal non géré: 0x${messageType.toString(16)} à offset ${offset-1}`)
          // Essayer de passer en avançant de 2 bytes par défaut
          if (offset + 1 < endOffset) {
            offset += 2
          }
          continue
      }
    } else if (status === 0xFF) {
      // Meta events
      if (offset >= endOffset) {
        console.warn(`  Meta event tronqué à offset ${offset}`)
        break
      }

      const metaType = dataView.getUint8(offset++)
      console.log(`  Meta event trouvé: type=0x${metaType.toString(16).padStart(2, '0')} à temps ${currentTime}`)

      const metaLength = readVariableLength(dataView, offset)
      offset += metaLength.bytesRead

      if (offset + metaLength.value > endOffset) {
        console.warn(`  Meta event dépasse la fin de track: longueur=${metaLength.value}, reste=${endOffset - offset}`)
        break
      }

      switch (metaType) {
        case 0x00: // Sequence Number
          event.type = 'sequenceNumber'
          if (metaLength.value === 2) {
            event.number = dataView.getUint16(offset)
          }
          console.log(`    Sequence Number: ${event.number || 'undefined'}`)
          break

        case 0x01: // Text Event
          event.type = 'textEvent'
          event.text = readString(dataView, offset, metaLength.value)
          console.log(`    Text Event: "${event.text}"`)
          break

        case 0x02: // Copyright Notice
          event.type = 'copyrightNotice'
          event.text = readString(dataView, offset, metaLength.value)
          console.log(`    Copyright: "${event.text}"`)
          break

        case 0x03: // Track Name
          event.type = 'trackName'
          event.text = readString(dataView, offset, metaLength.value)
          console.log(`    Track Name: "${event.text}"`)
          break

        case 0x04: // Instrument Name
          event.type = 'instrumentName'
          event.text = readString(dataView, offset, metaLength.value)
          console.log(`    Instrument Name: "${event.text}"`)
          break

        case 0x05: // Lyric
          event.type = 'lyric'
          event.text = readString(dataView, offset, metaLength.value)
          console.log(`    Lyric: "${event.text}"`)
          break

        case 0x06: // Marker
          event.type = 'marker'
          event.text = readString(dataView, offset, metaLength.value)
          console.log(`    Marker: "${event.text}"`)
          break

        case 0x07: // Cue Point
          event.type = 'cuePoint'
          event.text = readString(dataView, offset, metaLength.value)
          console.log(`    Cue Point: "${event.text}"`)
          break

        case 0x20: // MIDI Channel Prefix
          event.type = 'midiChannelPrefix'
          if (metaLength.value === 1) {
            event.channel = dataView.getUint8(offset)
          }
          console.log(`    MIDI Channel Prefix: ${event.channel}`)
          break

        case 0x2F: // End of Track
          event.type = 'endOfTrack'
          console.log(`    End of Track à temps ${currentTime}`)
          break

        case 0x51: // Set Tempo
          event.type = 'setTempo'
          if (metaLength.value === 3) {
            event.microsecondsPerBeat = (dataView.getUint8(offset) << 16) |
                                      (dataView.getUint8(offset + 1) << 8) |
                                      dataView.getUint8(offset + 2)
            const bpm = 60000000 / event.microsecondsPerBeat
            console.log(`    Set Tempo: ${event.microsecondsPerBeat} μs/beat = ${bpm.toFixed(2)} BPM à temps ${currentTime}`)
          } else {
            console.warn(`    Set Tempo: longueur incorrecte ${metaLength.value} (attendu 3)`)
          }
          break

        case 0x54: // SMPTE Offset
          event.type = 'smpteOffset'
          if (metaLength.value === 5) {
            event.hour = dataView.getUint8(offset)
            event.min = dataView.getUint8(offset + 1)
            event.sec = dataView.getUint8(offset + 2)
            event.frame = dataView.getUint8(offset + 3)
            event.subFrame = dataView.getUint8(offset + 4)
          }
          console.log(`    SMPTE Offset: ${event.hour}:${event.min}:${event.sec}.${event.frame}.${event.subFrame}`)
          break

        case 0x58: // Time Signature
          event.type = 'timeSignature'
          if (metaLength.value === 4) {
            event.numerator = dataView.getUint8(offset)
            event.denominator = dataView.getUint8(offset + 1)
            event.clocksPerTick = dataView.getUint8(offset + 2)
            event.thirtySecondNotesPerQuarter = dataView.getUint8(offset + 3)
            console.log(`    🎵 TIME SIGNATURE: ${event.numerator}/${Math.pow(2, event.denominator)} à temps ${currentTime} (clocks/tick: ${event.clocksPerTick}, 32nds/quarter: ${event.thirtySecondNotesPerQuarter})`)
          } else {
            console.warn(`    Time Signature: longueur incorrecte ${metaLength.value} (attendu 4)`)
          }
          break

        case 0x59: // Key Signature
          event.type = 'keySignature'
          if (metaLength.value === 2) {
            event.key = dataView.getInt8(offset)
            event.scale = dataView.getUint8(offset + 1)
            console.log(`    Key Signature: clé=${event.key}, gamme=${event.scale} (${event.scale === 0 ? 'majeur' : 'mineur'}) à temps ${currentTime}`)
          } else {
            console.warn(`    Key Signature: longueur incorrecte ${metaLength.value} (attendu 2)`)
          }
          break

        case 0x7F: // Sequencer Specific
          event.type = 'sequencerSpecific'
          event.data = new Uint8Array(metaLength.value)
          for (let i = 0; i < metaLength.value; i++) {
            event.data[i] = dataView.getUint8(offset + i)
          }
          console.log(`    Sequencer Specific: ${metaLength.value} bytes`)
          break

        default:
          event.type = 'unknownMeta'
          event.metaType = metaType
          event.data = new Uint8Array(metaLength.value)
          for (let i = 0; i < metaLength.value; i++) {
            event.data[i] = dataView.getUint8(offset + i)
          }
          console.log(`    Meta event inconnu: type=0x${metaType.toString(16)}, longueur=${metaLength.value}`)
          break
      }

      offset += metaLength.value
    } else if (status === 0xF0 || status === 0xF7) {
      // System Exclusive
      event.type = 'sysex'
      const sysexLength = readVariableLength(dataView, offset)
      offset += sysexLength.bytesRead
      event.data = new Uint8Array(sysexLength.value)
      for (let i = 0; i < sysexLength.value; i++) {
        event.data[i] = dataView.getUint8(offset + i)
      }
      offset += sysexLength.value
      console.log(`  SysEx: ${sysexLength.value} bytes à temps ${currentTime}`)
    } else {
      console.warn(`  Événement non reconnu: status=0x${status.toString(16)} à offset ${offset-1}, temps ${currentTime}`)
      // Essayer de continuer en sautant cet événement
      continue
    }

    events.push(event)
  }

  console.log(`  Track ${trackIndex} terminée: ${events.length} événements parsés`)
  
  // Compter les types d'événements pour debug
  const eventCounts = {}
  events.forEach(e => {
    eventCounts[e.type] = (eventCounts[e.type] || 0) + 1
  })
  console.log(`    Types d'événements:`, eventCounts)

  return { events }
}

const readChunk = (dataView, offset) => {
  const type = String.fromCharCode(
    dataView.getUint8(offset),
    dataView.getUint8(offset + 1),
    dataView.getUint8(offset + 2),
    dataView.getUint8(offset + 3)
  )
  const length = dataView.getUint32(offset + 4)
  return { type, length }
}

const readVariableLength = (dataView, offset) => {
  let value = 0
  let bytesRead = 0
  let byte

  do {
    if (offset + bytesRead >= dataView.byteLength) {
      console.warn(`readVariableLength: dépassement du buffer à offset ${offset + bytesRead}`)
      break
    }
    byte = dataView.getUint8(offset + bytesRead)
    value = (value << 7) | (byte & 0x7F)
    bytesRead++
  } while (byte & 0x80 && bytesRead < 4) // Sécurité: max 4 bytes

  return { value, bytesRead }
}

const readString = (dataView, offset, length) => {
  let str = ''
  for (let i = 0; i < length; i++) {
    if (offset + i >= dataView.byteLength) {
      console.warn(`readString: dépassement du buffer à offset ${offset + i}`)
      break
    }
    str += String.fromCharCode(dataView.getUint8(offset + i))
  }
  return str
}

// Fonction de debug pour analyser un fichier MIDI
const debugMidiFile = (buffer) => {
  console.log('=== ANALYSE DÉTAILLÉE DU FICHIER MIDI ===')
  try {
    const result = parseMidiFile(buffer)
    
    console.log('\n=== RÉSUMÉ DES TIME SIGNATURES ===')
    let timeSignatureCount = 0
    result.tracks.forEach((track, trackIndex) => {
      const timeSignatures = track.events.filter(e => e.type === 'timeSignature')
      if (timeSignatures.length > 0) {
        console.log(`Track ${trackIndex}: ${timeSignatures.length} time signature(s)`)
        timeSignatures.forEach((sig, i) => {
          console.log(`  ${i+1}: ${sig.numerator}/${Math.pow(2, sig.denominator)}`)
        })
        timeSignatureCount += timeSignatures.length
      }
    })
    
    console.log(`\nTOTAL TIME SIGNATURES TROUVÉES: ${timeSignatureCount}`)
    return result
  } catch (error) {
    console.error('Erreur lors de l\'analyse:', error)
    return null
  }
}



  return {
    // State
    notes,
    tracks,
    selectedTrack,
    midiInfo,
    midiCC,
    tempoEvents,
    timeSignatureEvents,
    keySignatureEvents,
    selectedNote,
    snapEnabled,
    currentSnapDivision,
    snapDivisions,

    // Getters
    getSnapValue,
    getNoteById,
    getNotesByTrack,
    getSelectedTrack,
    getSelectedTrackNotes,
    getSelectedTrackCC,
    getTrackById,
    getTimeSignatureAtTime, 
    getTimeSignatureChanges,     

    // Actions
    selectTrack,
    clearTrackSelection,
    selectNote,
    updateNote,
    updateNoteVelocity,
    moveNote,
    resizeNote,
    snapToGrid,
    setSnapEnabled,
    setSnapDivision,
    addNote,
    deleteNote,
    addTrack,
    updateTrack,
    deleteTrack,
    loadMidiFile
  }
})
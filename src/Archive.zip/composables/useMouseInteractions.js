// useMouseInteractions.js - Corrections complètes pour lasso, brush et latence

import { ref, computed, onMounted, onUnmounted } from 'vue'

export function useMouseInteractions(config) {
  // États réactifs
  const isDragging = ref(false)
  const isSelecting = ref(false)
  const isBrushing = ref(false)
  const isCommandPressed = ref(false)
  
  const currentItem = ref(null)
  const brushedItem = ref(null)
  const selectedItems = ref([])
  
  // Variables pour la sélection
  const selectionStart = ref({ x: 0, y: 0 })
  const selectionEnd = ref({ x: 0, y: 0 })
  
  // Variables pour le drag
  const dragStart = ref({ x: 0, y: 0 })
  const dragInitialValues = ref(new Map())
  
  // Variables pour gérer proprement les états
  let mouseDownStarted = false
  let currentOperation = null // 'drag', 'select', 'brush', null
  let lastBrushedItemId = null // Pour éviter les répétitions en mode brush
  let pendingUpdates = new Map() // Pour gérer les mises à jour par batch
  let updateTimeout = null
  
  // Style du rectangle de sélection
  const getSelectionRectangleStyle = () => {
    if (!isSelecting.value) return {}
    
    const left = Math.min(selectionStart.value.x, selectionEnd.value.x)
    const top = Math.min(selectionStart.value.y, selectionEnd.value.y)
    const width = Math.abs(selectionEnd.value.x - selectionStart.value.x)
    const height = Math.abs(selectionEnd.value.y - selectionStart.value.y)
    
    return {
      left: left + 'px',
      top: top + 'px',
      width: width + 'px',
      height: height + 'px'
    }
  }
  
  // Fonction pour nettoyer tous les États
  const resetAllStates = () => {
    isDragging.value = false
    isSelecting.value = false
    isBrushing.value = false
    isCommandPressed.value = false
    currentItem.value = null
    brushedItem.value = null
    dragInitialValues.value.clear()
    currentOperation = null
    mouseDownStarted = false
    lastBrushedItemId = null
    
    // Nettoyer les mises à jour en attente
    if (updateTimeout) {
      clearTimeout(updateTimeout)
      updateTimeout = null
    }
    pendingUpdates.clear()
  }
  
  // Fonction pour appliquer les mises à jour par batch (réduire la latence)
  const flushPendingUpdates = () => {
    if (pendingUpdates.size === 0) return
    
    // Appliquer toutes les mises à jour en une fois
    for (const [itemId, value] of pendingUpdates) {
      if (config.applyUpdate) {
        config.applyUpdate(itemId, value, true)
      }
    }
    
    pendingUpdates.clear()
  }
  
  const scheduleBatchUpdate = (itemId, value) => {
    pendingUpdates.set(itemId, value)
    
    if (updateTimeout) {
      clearTimeout(updateTimeout)
    }
    
    // Mise à jour immédiate pour la réactivité visuelle
    if (config.applyUpdate) {
      config.applyUpdate(itemId, value, false)
    }
    
    // Batch update après un court délai
    updateTimeout = setTimeout(() => {
      flushPendingUpdates()
      updateTimeout = null
    }, 16) // ~60fps
  }
  
  // Gestionnaire mousedown
  const handleMouseDown = (event, item = null) => {
    event.preventDefault()
    event.stopPropagation()
    
    if (!config.containerRef?.value) return
    
    // S'assurer qu'on part d'un état propre
    resetAllStates()
    mouseDownStarted = true
    
    const rect = config.containerRef.value.getBoundingClientRect()
    const relativeX = event.clientX - rect.left
    const relativeY = event.clientY - rect.top
    
    // Mode brush (Cmd/Ctrl + clic) - CORRECTION MAJEURE
    if (event.metaKey || event.ctrlKey) {
      currentOperation = 'brush'
      isBrushing.value = true
      isCommandPressed.value = true
      
      if (!item) {
        // CORRECTION: Utiliser les coordonnées relatives au conteneur pour findItemAtPosition
        item = config.findItemAtPosition(event.clientX, event.clientY)
      }
      
      if (item) {
        brushedItem.value = item
        lastBrushedItemId = item.id
        
        // Appliquer immédiatement la nouvelle vélocité
        const newVelocity = config.calculateValueFromPosition(event.clientY)
        scheduleBatchUpdate(item.id, newVelocity)
        
        if (config.onBrushStart) {
          config.onBrushStart(event, item)
        }
      }
      return
    }
    
    // Mode drag sur un item
    if (item) {
      currentOperation = 'drag'
      isDragging.value = true
      currentItem.value = { ...item }
      dragStart.value = { x: event.clientX, y: event.clientY }
      
      // Stocker les valeurs initiales
      const itemsToUpdate = selectedItems.value.includes(item.id) 
        ? selectedItems.value 
        : [item.id]
      
      dragInitialValues.value.clear()
      if (config.getCurrentItemValues) {
        const currentValues = config.getCurrentItemValues(itemsToUpdate)
        currentValues.forEach((value, key) => {
          dragInitialValues.value.set(key, value)
        })
      } else {
        // Fallback si getCurrentItemValues n'est pas disponible
        dragInitialValues.value.set(item.id, { id: item.id, velocity: item.velocity, value: item.velocity })
      }
      
      if (config.onDragStart) {
        config.onDragStart(event, item, selectedItems.value)
      }
      return
    }
    
    // Mode sélection lasso - CORRECTION MAJEURE
    currentOperation = 'select'
    isSelecting.value = true
    selectionStart.value = { x: relativeX, y: relativeY }
    selectionEnd.value = { x: relativeX, y: relativeY }
    
    if (config.onSelectionStart) {
      config.onSelectionStart(event, { x: relativeX, y: relativeY })
    }
  }
  
  // Gestionnaire mousemove
  const handleMouseMove = (event) => {
    if (!mouseDownStarted || !config.containerRef?.value) return
    
    const rect = config.containerRef.value.getBoundingClientRect()
    const relativeX = event.clientX - rect.left
    const relativeY = event.clientY - rect.top
    
    // Mode brush - CORRECTION: suivre la souris et modifier toutes les barres traversées
    if (currentOperation === 'brush' && isBrushing.value) {
      const item = config.findItemAtPosition(event.clientX, event.clientY)
      if (item && item.id !== lastBrushedItemId) {
        // Nouvelle barre détectée
        const newVelocity = config.calculateValueFromPosition(event.clientY)
        scheduleBatchUpdate(item.id, newVelocity)
        
        brushedItem.value = item
        lastBrushedItemId = item.id
        
        if (config.onBrushMove) {
          config.onBrushMove(event, item)
        }
      } else if (item && item.id === lastBrushedItemId) {
        // Même barre, mettre à jour la vélocité
        const newVelocity = config.calculateValueFromPosition(event.clientY)
        scheduleBatchUpdate(item.id, newVelocity)
      }
      return
    }
    
    // Mode drag - CORRECTION: Réduire la latence avec des mises à jour optimisées
    if (currentOperation === 'drag' && isDragging.value && currentItem.value) {
      let newValue
      if (config.calculateValueFromDelta) {
        const initialValue = dragInitialValues.value.get(currentItem.value.id)?.value || currentItem.value.velocity
        newValue = config.calculateValueFromDelta(event.clientY, initialValue, dragStart.value.y)
      } else {
        newValue = config.calculateValueFromPosition(event.clientY)
      }
      
      // Clamp la valeur
      newValue = Math.max(config.valueRange.min, Math.min(config.valueRange.max, newValue))
      
      // Mettre à jour l'item courant
      currentItem.value = { ...currentItem.value, value: newValue, velocity: newValue }
      
      // Appliquer la mise à jour avec optimisation
      const itemsToUpdate = selectedItems.value.includes(currentItem.value.id) 
        ? selectedItems.value 
        : [currentItem.value.id]
      
      itemsToUpdate.forEach(itemId => {
        let itemValue = newValue
        
        // Pour les sélections multiples, appliquer le delta proportionnellement
        if (itemsToUpdate.length > 1 && dragInitialValues.value.has(itemId)) {
          const initialItemValue = dragInitialValues.value.get(itemId).value
          const initialCurrentValue = dragInitialValues.value.get(currentItem.value.id)?.value || currentItem.value.velocity
          const deltaValue = newValue - initialCurrentValue
          itemValue = Math.max(config.valueRange.min, Math.min(config.valueRange.max, initialItemValue + deltaValue))
        }
        
        // Utiliser le système de batch pour réduire la latence
        scheduleBatchUpdate(itemId, itemValue)
      })
      
      if (config.onDragMove) {
        config.onDragMove(event, currentItem.value, 'drag')
      }
      return
    }
    
    // Mode sélection lasso - CORRECTION: Améliorer la détection des éléments
    if (currentOperation === 'select' && isSelecting.value) {
      selectionEnd.value = { x: relativeX, y: relativeY }
      
      // CORRECTION: Calculer les bounds en coordonnées absolues pour tenir compte des signatures
      const absoluteBounds = {
        startX: selectionStart.value.x,
        startY: selectionStart.value.y,
        endX: selectionEnd.value.x,
        endY: selectionEnd.value.y,
        // Ajouter les coordonnées du conteneur pour les calculs de position
        containerLeft: rect.left,
        containerTop: rect.top
      }
      
      // Trouver les items dans la sélection
      let itemsInSelection = []
      if (config.getItemsByBounds) {
        itemsInSelection = config.getItemsByBounds(absoluteBounds)
      }
      
      if (config.onSelectionUpdate) {
        config.onSelectionUpdate(itemsInSelection, absoluteBounds)
      }
      return
    }
  }
  
  // Gestionnaire mouseup
  const handleMouseUp = (event) => {
    if (!mouseDownStarted) return
    
    // S'assurer que toutes les mises à jour en attente sont appliquées
    flushPendingUpdates()
    
    // Mode brush
    if (currentOperation === 'brush' && isBrushing.value) {
      if (config.onBrushEnd) {
        config.onBrushEnd()
      }
      resetAllStates()
      return
    }
    
    // Mode drag
    if (currentOperation === 'drag' && isDragging.value) {
      if (config.onDragEnd) {
        const editedItems = selectedItems.value.includes(currentItem.value?.id) 
          ? selectedItems.value 
          : [currentItem.value?.id].filter(id => id !== undefined)
        config.onDragEnd(editedItems)
      }
      
      resetAllStates()
      return
    }
    
    // Mode sélection lasso
    if (currentOperation === 'select' && isSelecting.value) {
      const rect = config.containerRef.value.getBoundingClientRect()
      const absoluteBounds = {
        startX: selectionStart.value.x,
        startY: selectionStart.value.y,
        endX: selectionEnd.value.x,
        endY: selectionEnd.value.y,
        containerLeft: rect.left,
        containerTop: rect.top
      }
      
      let selectedItemsList = []
      if (config.getItemsByBounds) {
        selectedItemsList = config.getItemsByBounds(absoluteBounds)
      }
      
      // Mettre à jour la sélection correctement
      if (!event.shiftKey) {
        selectedItems.value = selectedItemsList.map(item => item.id)
      } else {
        // Mode additif avec Shift
        const newIds = selectedItemsList.map(item => item.id)
        const combined = [...new Set([...selectedItems.value, ...newIds])]
        selectedItems.value = combined
      }
      
      if (config.onSelectionEnd) {
        config.onSelectionEnd(selectedItemsList)
      }
      
      resetAllStates()
      return
    }
    
    // Fallback: s'assurer qu'on remet tout à zéro
    resetAllStates()
  }
  
  // Écouteurs globaux pour le suivi de la souris
  const setupGlobalListeners = () => {
    const handleGlobalMouseMove = (event) => {
      // Seulement si une opération est en cours
      if (mouseDownStarted && (isDragging.value || isSelecting.value || isBrushing.value)) {
        handleMouseMove(event)
      }
    }
    
    const handleGlobalMouseUp = (event) => {
      // Toujours traiter le mouseup global pour éviter les états bloqués
      if (mouseDownStarted) {
        handleMouseUp(event)
      }
    }
    
    // Gérer le cas où la souris quitte complètement la fenêtre
    const handleMouseLeave = (event) => {
      if (mouseDownStarted && (isDragging.value || isSelecting.value || isBrushing.value)) {
        handleMouseUp(event)
      }
    }
    
    document.addEventListener('mousemove', handleGlobalMouseMove, { passive: false })
    document.addEventListener('mouseup', handleGlobalMouseUp, { passive: false })
    document.addEventListener('mouseleave', handleMouseLeave, { passive: false })
    
    return () => {
      document.removeEventListener('mousemove', handleGlobalMouseMove)
      document.removeEventListener('mouseup', handleGlobalMouseUp)
      document.removeEventListener('mouseleave', handleMouseLeave)
    }
  }
  
  // Lifecycle
  let removeGlobalListeners = null
  
  onMounted(() => {
    removeGlobalListeners = setupGlobalListeners()
  })
  
  onUnmounted(() => {
    if (removeGlobalListeners) {
      removeGlobalListeners()
    }
    resetAllStates()
  })
  
  return {
    // États
    isDragging,
    isSelecting,
    isBrushing,
    isCommandPressed,
    currentItem,
    brushedItem,
    selectedItems,
    
    // Méthodes
    getSelectionRectangleStyle,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    resetAllStates
  }
}
<template>
  <div class="midi-lane-infos">
    <!-- Affichage de la vélocité pendant l'édition -->
    <div
      v-if="uiStore.velocityDisplay.visible"
      class="velocity-display"
    >
      <div class="velocity-label">{{ selectedLane.label }}</div>
      <div class="velocity-value">{{ uiStore.velocityDisplay.value }}</div>
    </div>
  </div>
</template>

<script setup>
import { useUIStore } from '@/stores/ui'

const props = defineProps({
  selectedLane: {
    type: Object,
    default: null
  }
})

const uiStore = useUIStore()
</script>

<style scoped>
.midi-lane-infos {
  height: 100%;
  padding: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  background: var(--midi-lane-infos-bg, #f0f0f0);
}

.velocity-display {
  background: var(--velocity-display-bg, rgba(0, 0, 0, 0.8));
  color: var(--velocity-display-fg, #fff);
  padding: 8px 12px;
  border-radius: 6px;
  text-align: center;
  margin-bottom: 8px;
  min-width: 60px;
  box-shadow: 0 2px 4px var(--velocity-display-shadow, rgba(0, 0, 0, 0.2));
}

.velocity-label {
  font-size: 10px;
  text-transform: uppercase;
  opacity: 0.8;
  margin-bottom: 2px;
}

.velocity-value {
  font-size: 16px;
  font-weight: bold;
}

.lane-info {
  text-align: center;
  color: var(--midi-lane-info-fg, #666);
}

.lane-name {
  font-size: 11px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-top: auto;
  margin-bottom: 8px;
}
</style>
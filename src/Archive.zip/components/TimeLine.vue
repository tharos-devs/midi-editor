<template>
  <div class="timeline" :style="{ width: totalWidth + 'px' }">
    <div class="timeline-ruler">
      <!-- Lignes de mesures -->
      <div
        v-for="measure in measures"
        :key="`measure-${measure.number}`"
        class="measure-container"
        :style="{ 
          left: measure.startPixel + 'px',
          width: measure.measureWidth + 'px'
        }"
        :data-measure="measure.number"
      >
        <!-- Ligne principale de mesure -->
        <div class="measure-line" :class="{ 'signature-change': measure.signatureChange }"></div>
        
        <!-- Header avec numéro -->
        <div class="measure-header">
          <div class="measure-number">{{ measure.number }}</div>
        </div>
        
        <!-- Beats dans cette mesure -->
        <div class="beats-container">
          <div
            v-for="beatIndex in measure.beatsCount"
            :key="`beat-${measure.number}-${beatIndex}`"
            class="beat-line"
            :class="{ 'first-beat': beatIndex === 1 }"
            :style="{ 
              left: ((beatIndex - 1) * measure.beatWidth) + 'px'
            }"
          >
            <div v-if="beatIndex > 1" class="beat-label">{{ measure.number }}{{ '.' }}{{ beatIndex }}</div>
          </div>
        </div>

        <!-- Fond coloré selon la signature -->
        <div class="measure-background" 
             :class="`sig-${measure.timeSignature.numerator}-${measure.timeSignature.denominator}`">
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useTimeSignature } from '@/composables/useTimeSignature'
import { useUIStore } from '@/stores/ui'

const uiStore = useUIStore()

// Utiliser le composable de signature rythmique
const timeSignatureComposable = useTimeSignature()

const measuresWithSignatures = computed(() => {
  return timeSignatureComposable?.measuresWithSignatures?.value || []
})

const totalWidth = computed(() => {
  return timeSignatureComposable?.totalWidth?.value || 800
})

const measures = computed(() => measuresWithSignatures.value)

// Exposition sécurisée des données
defineExpose({
  measuresWithSignatures: measures,
  totalWidth,
  getAllMeasureLines: timeSignatureComposable?.getAllMeasureLines || computed(() => []),
  getAllBeatLines: timeSignatureComposable?.getAllBeatLines || computed(() => [])
})
</script>

<style scoped>
.timeline {
  height: 100%;
  position: relative;
  background: linear-gradient(to bottom, #fafafa 0%, #f0f0f0 100%);
  min-width: 100%;
  border-bottom: 1px solid #ddd;
  box-shadow: inset 0 -8px 12px -6px var(--timeline-shadow, rgba(0, 0, 0, 0.15));
}

.timeline-ruler {
  height: 100%;
  position: relative;
  overflow: visible;
}

/* Container pour chaque mesure */
.measure-container {
  position: absolute;
  top: 0;
  height: 100%;
  z-index: 1;
}

/* Ligne principale de mesure */
.measure-line {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 1px;
  background-color: var(--timeline-measure, #333);
  z-index: 3;
}

/* Header de mesure */
.measure-header {
  position: absolute;
  top: 4px;
  left: 4px;
  z-index: 10;
  pointer-events: none;
}

.measure-number {
  font-size: 14px;
  font-weight: bold;
  color: #333;
  text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.8);
}

/* Container des beats */
.beats-container {
  position: relative;
  top: 0;
  width: 100%;
  height: 100%;
}

/* Lignes de beats */
.beat-line {
  position: absolute;
  top: 30px;
  height: calc(100% - 30px);
  width: 1px;
  background-color: #666;
  opacity: 0.6;
  z-index: 2;
}

.beat-line.first-beat {
  opacity: 0;
}

.beat-label {
  position: absolute;
  top: -25px;
  left: 2px;
  font-size: 11px;
  color: var(--timeline-beat, #333);
  font-weight: normal;
}

/* Fond de mesure */
.measure-background {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
  opacity: 0.3;
}
</style>
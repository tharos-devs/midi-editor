<template>
  <div class="signature-ruler" :style="{ width: totalWidth + 'px' }">
    <div class="signature-ruler-content">
      <!-- Signatures rythmiques -->
      <div
        v-for="measure in measuresWithSignatures"
        :key="measure.number"
        class="signature-mark"
        :style="{ left: measure.startPixel + 'px' }"
      >
        <!-- Barre de début de mesure -->
        <div class="measure-bar"></div>
        
        <!-- Signature rythmique -->
        <div 
          v-if="measure.signatureChange"
          class="time-signature-text"
          :title="`Signature rythmique: ${measure.timeSignature.numerator}/${measure.timeSignature.denominator}`"
        >
          {{ measure.timeSignature.numerator }}/{{ measure.timeSignature.denominator }}
        </div>
        
        <!-- Lignes de subdivisions (beats) -->
        <div class="beat-subdivisions">
          <div
            v-for="beat in measure.beats"
            :key="beat"
            class="beat-subdivision"
            :style="{ 
              left: (beat - 1) * measure.beatWidth + 'px',
              opacity: beat === 1 ? 0 : 0.6 
            }"
            v-show="beat > 1"
          ></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useTimeSignature } from '@/composables/useTimeSignature'

// Utiliser le composable de signature rythmique
const {
  measuresWithSignatures,
  totalWidth
} = useTimeSignature()

// Exposition des données pour les composants parents
defineExpose({
  measuresWithSignatures,
  totalWidth
})
</script>

<style scoped>
.signature-ruler {
  height: 20px;
  position: relative;
  background: linear-gradient(
    to bottom,
    var(--signature-ruler-bg, #f8f9fa) 0%,
    var(--signature-ruler-bg-gradient, #e9ecef) 100%
  );
  min-width: 100%;
  border-bottom: 1px solid var(--signature-ruler-border, #dee2e6);
  border-top: 1px solid var(--signature-ruler-border, #dee2e6);
}

.signature-ruler-content {
  height: 100%;
  position: relative;
  overflow: hidden;
}

.signature-mark {
  position: absolute;
  top: 0;
  height: 100%;
  z-index: 2;
}

.measure-bar {
  position: absolute;
  top: 0;
  height: 100%;
  border-left: 2px solid var(--signature-measure-bar, #333);
  z-index: 2;
}

.time-signature-text {
  position: absolute;
  top: 50%;
  left: 6px;
  transform: translateY(-50%);
  font-size: 13px;
  font-weight: bold;
  color: var(--signature-text, #333);
  z-index: 5;
  transition: color 0.2s ease;
}

.time-signature-text:hover {
  color: var(--signature-text-hover, #007bff);
}

.beat-subdivisions {
  position: relative;
  height: 100%;
}

.beat-subdivision {
  position: absolute;
  top: 0;
  height: 100%;
  border-left: 1px solid var(--signature-beat, #666);
  opacity: 0.4;
  z-index: 1;
  transition: opacity 0.2s ease;
}

.current-signature-indicator {
  position: absolute;
  top: 50%;
  right: 8px;
  transform: translateY(-50%);
  background: var(--signature-indicator-bg, rgba(255, 255, 255, 0.95));
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid var(--signature-indicator-border, #d9d9d9);
  box-shadow: 0 1px 3px var(--signature-indicator-shadow, rgba(0, 0, 0, 0.1));
  z-index: 10;
  font-size: 11px;
}

/* États spéciaux */
.signature-ruler:hover .beat-subdivision {
  opacity: 0.6;
}
</style>
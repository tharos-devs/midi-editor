<template>
  <div class="selection-rectangle" />
</template>

<script setup>
// Ce composant est purement stylistique
// Le style est passé via les props du parent
</script>

<style scoped>
.selection-rectangle {
  position: absolute;
  border: 2px dashed var(--velocity-selection-rect, #2196F3);
  background: var(--velocity-selection-rect-bg, rgba(33, 150, 243, 0.1));
  pointer-events: none;
  z-index: 8;
  border-radius: 2px;
}

/* Mode sombre */
@media (prefers-color-scheme: dark) {
  .selection-rectangle {
    --velocity-selection-rect: #4CAF50;
    --velocity-selection-rect-bg: rgba(76, 175, 80, 0.15);
  }
}
</style>
// VelocityBar.vue - Script optimisé pour réduire la latence

<template>
  <div
    class="velocity-bar interactive-item"
    :class="barClasses"
    :style="barStyle"
    @mousedown="$emit('mousedown', $event)"
    @click="$emit('click', $event)"
  >
    <div 
      class="velocity-bar-fill" 
      :style="fillStyle"
    />
  </div>
</template>

<script setup>
import { computed, watchEffect, ref } from 'vue'
import { useTimeSignature } from '@/composables/useTimeSignature'
import { useVelocityCalculations } from '@/composables/useVelocityCalculations'
import { useColorsStore } from '@/stores/colors'

const props = defineProps({
  note: {
    type: Object,
    required: true
  },
  laneHeight: {
    type: Number,
    required: true
  },
  usableHeight: {
    type: Number,
    required: true
  },
  velocityBarWidth: {
    type: Number,
    required: true
  },
  isSelected: {
    type: Boolean,
    default: false
  },
  isSingleSelected: {
    type: Boolean,
    default: false
  },
  isInSelection: {
    type: Boolean,
    default: false
  },
  isBrushed: {
    type: Boolean,
    default: false
  },
  isDragging: {
    type: Boolean,
    default: false
  }
})

defineEmits(['mousedown', 'click'])

const { timeToPixelsWithSignatures } = useTimeSignature()
const { velocityToY } = useVelocityCalculations()
const colorsStore = useColorsStore()

// Constantes
const VELOCITY_MARGIN_TOP = 5

// CORRECTION: Cache pour optimiser les calculs de position
const cachedPosition = ref(null)
const lastNoteTime = ref(null)

// CORRECTION: Calculer la position avec cache pour éviter les recalculs
const calculateLeftPosition = () => {
  const noteTime = props.note.time || 0
  
  // Si le temps n'a pas changé, utiliser le cache
  if (lastNoteTime.value === noteTime && cachedPosition.value !== null) {
    return cachedPosition.value
  }
  
  try {
    let position
    if (timeToPixelsWithSignatures) {
      position = timeToPixelsWithSignatures(noteTime)
    } else {
      // Fallback simple
      position = noteTime * 60 // 60 pixels par beat
    }
    
    // Mettre à jour le cache
    cachedPosition.value = position
    lastNoteTime.value = noteTime
    
    return position
  } catch (error) {
    console.warn('Erreur calcul position:', error)
    return cachedPosition.value || 0
  }
}

// Classes CSS dynamiques avec mémoisation
const barClasses = computed(() => {
  // CORRECTION: Optimiser l'ordre de priorité pour éviter les conflits
  const classes = {
    'dragging': props.isDragging,
    'brushed': props.isBrushed && !props.isDragging,
    'single-selected': props.isSingleSelected && !props.isDragging && !props.isBrushed,
    'selected': props.isSelected && !props.isSingleSelected && !props.isDragging && !props.isBrushed,
    'in-selection': props.isInSelection && !props.isSelected && !props.isDragging && !props.isBrushed
  }
  
  return classes
})

// Style de la barre avec optimisation
const barStyle = computed(() => {
  const leftPosition = calculateLeftPosition()
    
  return {
    left: leftPosition + 'px',
    width: props.velocityBarWidth + 'px',
    height: '100%',
    position: 'absolute',
    bottom: '0',
    // CORRECTION: Optimiser les z-index pour éviter les conflits visuels
    zIndex: props.isDragging ? 15 : 
            props.isBrushed ? 12 : 
            props.isSingleSelected ? 10 : 
            props.isSelected ? 8 : 
            props.isInSelection ? 6 : 5,
    cursor: props.isDragging ? 'ns-resize' : 'pointer',
    // CORRECTION: Ajouter will-change pour optimiser les performances
    willChange: props.isDragging || props.isBrushed ? 'transform' : 'auto'
  }
})

// CORRECTION: Cache pour les calculs de vélocité
const cachedVelocityCalc = ref(null)
const lastVelocityValue = ref(null)

// Style du fill avec optimisations et cache
const fillStyle = computed(() => {
  const midiVelocity = props.note.velocity !== undefined ? props.note.velocity : 64
  const clampedVelocity = Math.max(0, Math.min(127, Math.round(midiVelocity)))
  
  // Utiliser le cache si la vélocité n'a pas changé
  if (lastVelocityValue.value === clampedVelocity && cachedVelocityCalc.value) {
    return {
      ...cachedVelocityCalc.value,
      backgroundColor: getBackgroundColor(clampedVelocity),
      transition: props.isDragging ? 'none' : 'height 0.05s ease, background-color 0.05s ease'
    }
  }
  
  // Recalculer seulement si nécessaire
  const barTopY = velocityToY(clampedVelocity, props.usableHeight, VELOCITY_MARGIN_TOP)
  const barBottomY = velocityToY(0, props.usableHeight, VELOCITY_MARGIN_TOP)
  const barHeightPx = Math.max(2, barBottomY - barTopY)
  const heightPercentage = (barHeightPx / props.laneHeight) * 100

  // Mettre à jour le cache
  const calculatedStyle = {
    height: heightPercentage + '%',
    width: '100%'
  }
  
  cachedVelocityCalc.value = calculatedStyle
  lastVelocityValue.value = clampedVelocity

  return {
    ...calculatedStyle,
    backgroundColor: getBackgroundColor(clampedVelocity),
    transition: props.isDragging ? 'none' : 'height 0.05s ease, background-color 0.05s ease',
    // CORRECTION: Optimisations GPU
    willChange: props.isDragging || props.isBrushed ? 'height, background-color' : 'auto',
    transform: 'translateZ(0)' // Force GPU acceleration
  }
})

// CORRECTION: Fonction optimisée pour la couleur de fond
const getBackgroundColor = (clampedVelocity) => {
  // Ordre de priorité optimisé des états
  if (props.isDragging) {
    return '#2196F3' // Bleu pour le drag
  }
  if (props.isBrushed) {
    return '#FF6B35' // Orange pour le brush
  }
  if (props.isSingleSelected) {
    return '#2196F3' // Bleu pour sélection unique
  }
  if (props.isSelected) {
    return '#000000' // Noir pour sélection multiple
  }
  if (props.isInSelection) {
    return '#4CAF50' // Vert pour preview de sélection
  }
  if (clampedVelocity === 0) {
    return '#ff4444' // Rouge pour vélocité nulle
  }
  
  // Couleur par défaut basée sur la vélocité
  return colorsStore.getVelocityColor(clampedVelocity)
}

// CORRECTION: Nettoyer le cache quand les props changent significativement
watchEffect(() => {
  // Invalider le cache de position si le temps change
  if (props.note.time !== lastNoteTime.value) {
    cachedPosition.value = null
  }
  
  // Invalider le cache de vélocité si la vélocité change
  if (props.note.velocity !== lastVelocityValue.value) {
    cachedVelocityCalc.value = null
  }
})
</script>

<style scoped>
.velocity-bar {
  border-radius: 2px;
  box-sizing: border-box;
  pointer-events: auto;
  min-height: 100%;
  border: 2px solid transparent;
  transition: all 0.1s ease;
  /* CORRECTION: Optimisations pour les performances */
  contain: layout style paint;
  will-change: auto;
}

.velocity-bar:hover {
  border-color: var(--velocity-hover, rgba(33, 150, 243, 0.5));
  box-shadow: 0 1px 4px rgba(33, 150, 243, 0.2);
}

/* CORRECTION: États de sélection avec priorités clarifiées */
.velocity-bar.dragging {
  border-color: var(--velocity-single-drag, #2196F3) !important;
  box-shadow: 0 2px 8px rgba(33, 150, 243, 0.4);
  cursor: ns-resize !important;
  z-index: 15 !important;
}

.velocity-bar.brushed {
  border-color: var(--velocity-brushed, #FF6B35) !important;
  z-index: 12 !important;
}

.velocity-bar.single-selected {
  border-color: var(--velocity-single-selected, #2196F3) !important;
  z-index: 10 !important;
}

.velocity-bar.selected {
  border-color: var(--velocity-selected, #000000) !important;
  z-index: 8 !important;
}

.velocity-bar.in-selection {
  border-color: var(--velocity-preview-selection, #4CAF50) !important;
  z-index: 6 !important;
}

.velocity-bar-fill {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  border-radius: 1px;
  min-height: 2px;
  pointer-events: none;
  /* CORRECTION: Optimisations GPU et performances */
  will-change: height, background-color;
  transform: translateZ(0);
  contain: layout style paint;
  transition: inherit;
}

/* États de focus pour l'accessibilité */
.velocity-bar:focus-visible {
  outline: 2px solid var(--velocity-focus, #2196F3);
  outline-offset: 2px;
}
</style>
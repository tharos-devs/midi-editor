<template>
  <div 
    class="velocity-lane" 
    ref="velocityLaneRef"
    :class="{ 'brush-mode': isBrushing }"
    @mousedown="handleMouseDown"
    @mouseup="handleMouseUp"
    @mousemove="handleMouseMove"
  >
    <!-- Rectangle de sélection -->
    <SelectionRectangle 
      v-if="isSelecting"
      :style="getSelectionRectangleStyle()"
    />
        
    <!-- Grille de mesures -->
    <div class="measures-grid" :style="{ width: totalWidth + 'px' }">
      <!-- Zone d'affichage des vélocités -->
      <VelocityDisplayArea
        :lane-height="laneHeight"
        :usable-height="usableVelocityHeight"
        :visible-notes="visibleNotes"
        :selected-items="selectedItems"
        :preview-selected-items="previewSelectedItems"
        :is-command-pressed="isCommandPressed"
        :brushed-item="brushedItem"
        :is-dragging="isDragging"
        :current-item="currentItem"
        :velocity-bar-width="velocityBarWidth"
        @velocity-bar-mousedown="handleVelocityBarMouseDown"
        @velocity-bar-click="handleVelocityBarClick"
      />

      <!-- Grille de temps -->
      <TimeGrid 
        :measures="measures"
        :visible-measures="visibleMeasures"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch, nextTick } from 'vue'
import { useUIStore } from '@/stores/ui'
import { useMidiStore } from '@/stores/midi'
import { useTimeSignature } from '@/composables/useTimeSignature'
import { useMouseInteractions } from '@/composables/useMouseInteractions'
import { useVelocityCalculations } from '@/composables/useVelocityCalculations'

// Composants
import SelectionRectangle from '@/components/lanes/velocity/SelectionRectangle.vue'
import VelocityDisplayArea from '@/components/lanes/velocity/VelocityDisplayArea.vue'
import TimeGrid from '@/components/lanes/velocity/TimeGrid.vue'

const props = defineProps({
  totalMeasures: {
    type: Number,
    default: 32
  },
  visibleMeasures: {
    type: Array,
    default: () => []
  }
})

const uiStore = useUIStore()
const midiStore = useMidiStore()
const velocityLaneRef = ref(null)

// Composables
const { toneToMidi, midiToTone, velocityToY, yToVelocity } = useVelocityCalculations()

// Utiliser le composable de signature rythmique
const timeSignatureComposable = useTimeSignature()

const totalWidth = computed(() => {
  return timeSignatureComposable?.totalWidth?.value || 800
})

// CORRECTION: Utiliser la fonction avec gestion des signatures
const timeToPixels = (time) => {
  if (timeSignatureComposable?.timeToPixelsWithSignatures) {
    return timeSignatureComposable.timeToPixelsWithSignatures(time)
  }
  // Fallback simple
  const pixelsPerBeat = 60
  return time * pixelsPerBeat
}

// État local
const previewSelectedItems = ref([])
const isClickPending = ref(false)
const laneHeightPx = ref(100)

// Constantes
const VELOCITY_MARGIN_TOP = 2
const VELOCITY_MARGIN_BOTTOM = 2
const FIXED_BAR_WIDTH = 8

// Computed properties avec gestion des signatures
const measures = computed(() => {
  // Si le composable timeSignature a des mesures, les utiliser
  if (timeSignatureComposable?.measures?.value) {
    return timeSignatureComposable.measures.value
  }
  
  // Fallback simple
  const simpleMeasures = []
  const pixelsPerBeat = 60
  
  for (let i = 0; i < props.totalMeasures; i++) {
    const measure = {
      number: i + 1,
      timeSignature: { numerator: 4, denominator: 4 },
      startTime: i * 4,
      duration: 4,
      startPixel: i * 4 * pixelsPerBeat,
      beatWidth: pixelsPerBeat,
      beats: [1, 2, 3, 4],
      signatureChange: false
    }
    simpleMeasures.push(measure)
  }
  return simpleMeasures
})

const selectedTrackNotes = computed(() => {
  if (midiStore.selectedTrack === null || midiStore.selectedTrack === undefined) {
    return []
  }
  return (midiStore.notes || []).filter(note => note.trackId === midiStore.selectedTrack)
})

const visibleNotes = computed(() => {
  return selectedTrackNotes.value.map(note => {
    const toneVelocity = note.velocity !== undefined ? note.velocity : 0.5
    const midiVelocity = toneToMidi(toneVelocity)
    
    return { 
      ...note, 
      velocity: midiVelocity,
      originalVelocity: toneVelocity
    }
  })
})

const laneHeight = computed(() => Math.max(40, laneHeightPx.value - 1))
const usableVelocityHeight = computed(() => Math.max(20, laneHeight.value - VELOCITY_MARGIN_TOP - VELOCITY_MARGIN_BOTTOM))

const velocityBarWidth = computed(() => FIXED_BAR_WIDTH)

// CORRECTION: Fonction pour trouver un item à une position donnée
const findItemAtPosition = (clientX, clientY) => {
  if (!velocityLaneRef.value) return null
  
  const rect = velocityLaneRef.value.getBoundingClientRect()
  const relativeX = clientX - rect.left
  const barWidth = velocityBarWidth.value
  const tolerance = Math.max(4, barWidth * 0.5)
  
  for (const note of visibleNotes.value) {
    try {
      // CORRECTION: Utiliser la fonction qui gère les signatures
      const leftPosition = timeToPixels(note.time || 0)
      if (relativeX >= (leftPosition - tolerance) && relativeX <= (leftPosition + barWidth + tolerance)) {
        return { 
          ...note, 
          id: note.id, 
          velocity: note.velocity,
          value: note.velocity
        }
      }
    } catch (error) {
      continue
    }
  }
  return null
}

const calculateVelocityFromPosition = (clientY) => {
  if (!velocityLaneRef.value) return 64
  const rect = velocityLaneRef.value.getBoundingClientRect()
  const relativeY = clientY - rect.top
  return yToVelocity(relativeY, usableVelocityHeight.value, VELOCITY_MARGIN_TOP)
}

const calculateVelocityFromDelta = (currentY, initialMidiValue, startY) => {
  if (!velocityLaneRef.value) return initialMidiValue

  const deltaY = currentY - startY
  const pixelRange = usableVelocityHeight.value
  
  const sensitivity = 1.2
  const velocityDelta = -(deltaY / pixelRange) * 127 * sensitivity
  const newMidiVelocity = initialMidiValue + velocityDelta
  
  return Math.max(0, Math.min(127, Math.round(newMidiVelocity)))
}

// CORRECTION: Fonction pour vérifier si une note est dans les bounds de sélection
const isNoteInSelectionBounds = (note, bounds) => {
  try {
    // CORRECTION: Utiliser la fonction qui gère les signatures
    const leftPosition = timeToPixels(note.time || 0)
    const noteLeft = leftPosition
    const noteRight = noteLeft + velocityBarWidth.value
    
    const selectionLeft = Math.min(bounds.startX, bounds.endX)
    const selectionRight = Math.max(bounds.startX, bounds.endX)
    const selectionTop = Math.min(bounds.startY, bounds.endY)
    const selectionBottom = Math.max(bounds.startY, bounds.endY)
    
    const horizontalOverlap = noteLeft <= selectionRight && noteRight >= selectionLeft
    const verticalOverlap = selectionTop <= laneHeight.value && selectionBottom >= 0
    
    return horizontalOverlap && verticalOverlap
  } catch (error) {
    console.warn('Erreur lors de la vérification des bounds:', error, note)
    return false
  }
}

// CORRECTION: Cache pour optimiser les mises à jour et réduire la latence
const updateCache = new Map()
let updateBatchTimeout = null

const updateNoteVelocity = (noteId, midiVelocity, isTemporary = false) => {
  const clampedMidi = Math.max(0, Math.min(127, Math.round(midiVelocity)))
  const toneVelocity = midiToTone(clampedMidi)
  
  // CORRECTION: Cache pour éviter les mises à jour redondantes
  const cacheKey = `${noteId}-${clampedMidi}`
  if (updateCache.has(cacheKey) && isTemporary) {
    return // Éviter les mises à jour redondantes
  }
  updateCache.set(cacheKey, Date.now())
  
  // Nettoyer le cache périodiquement
  if (updateCache.size > 100) {
    const now = Date.now()
    for (const [key, timestamp] of updateCache) {
      if (now - timestamp > 1000) { // 1 seconde
        updateCache.delete(key)
      }
    }
  }
  
  console.log(`Mise à jour note ${noteId}: MIDI ${clampedMidi} -> Tone ${toneVelocity}`)
  
  if (typeof midiStore.updateNote === 'function') {
    // CORRECTION: Utiliser nextTick pour les mises à jour non-temporaires
    if (!isTemporary) {
      nextTick(() => {
        midiStore.updateNote(noteId, { velocity: toneVelocity })
      })
    } else {
      midiStore.updateNote(noteId, { velocity: toneVelocity })
    }
  } else {
    console.warn('midiStore.updateNote n\'est pas disponible')
  }
}

// Configuration du composable useMouseInteractions
const mouseInteractions = useMouseInteractions({
  containerRef: velocityLaneRef,
  valueRange: { min: 0, max: 127 },
  updateMode: 'realtime',
  
  onDragStart: (event, item, selection) => {
    isClickPending.value = false
    console.log('Drag start:', item, 'Selection:', selection)
    
    if (typeof uiStore.showVelocityDisplay === 'function') {
      uiStore.showVelocityDisplay(Math.round(item.velocity || 0))
    }
  },

  onDragMove: (event, item, mode) => {
    if (typeof uiStore.updateVelocityDisplay === 'function') {
      uiStore.updateVelocityDisplay(Math.round(item.value || 0))
    }
  },

  onDragEnd: (editedItems) => {
    console.log('Drag end, items modifiés:', editedItems)
    
    if (typeof uiStore.hideVelocityDisplay === 'function') {
      uiStore.hideVelocityDisplay()
    }
  },
  
  onSelectionStart: (event, position) => {
    console.log('Selection start:', position)
    previewSelectedItems.value = []
  },
  
  onSelectionUpdate: (newSelection, bounds) => {
    console.log('Selection update:', newSelection.length, 'items')
    const selectedNoteIds = newSelection.map(note => note.id)
    previewSelectedItems.value = [...selectedNoteIds]
  },
  
  onSelectionEnd: (selection) => {
    console.log('Selection end:', selection.length, 'items sélectionnés')
    previewSelectedItems.value = []
  },
  
  onBrushStart: (event, item) => {
    console.log('Brush start sur:', item.id)
  },

  onBrushMove: (event, item) => {
    console.log('Brush move sur:', item.id)
  },

  onBrushEnd: () => {
    console.log('Brush end')
  },
  
  findItemAtPosition,
  calculateValueFromPosition: calculateVelocityFromPosition,
  calculateValueFromDelta: calculateVelocityFromDelta,

  // Fonction d'application des mises à jour
  applyUpdate: updateNoteVelocity,

  // CORRECTION: Améliorer getItemsByBounds avec gestion des signatures
  getItemsByBounds: (bounds) => {
    const itemsInBounds = visibleNotes.value.filter(note => isNoteInSelectionBounds(note, bounds))
    console.log('Items dans les bounds:', itemsInBounds.length, bounds)
    return itemsInBounds
  },

  getCurrentItemValues: (itemIds) => {
    const currentValues = new Map()
    
    itemIds.forEach(itemId => {
      const storeNote = midiStore.notes?.find(note => note.id === itemId)
      if (storeNote) {
        const toneVelocity = storeNote.velocity !== undefined ? storeNote.velocity : 0.5
        const midiVelocity = toneToMidi(toneVelocity)
        
        currentValues.set(itemId, {
          id: storeNote.id,
          velocity: midiVelocity,
          value: midiVelocity
        })
      }
    })
    
    return currentValues
  }
})

// Extraire les propriétés du composable
const {
  isDragging,
  isSelecting,
  isBrushing,
  isCommandPressed,
  currentItem,
  brushedItem,
  selectedItems,
  getSelectionRectangleStyle,
  handleMouseDown,
  handleMouseMove,
  handleMouseUp
} = mouseInteractions

// Gestionnaires d'événements
const handleVelocityBarMouseDown = (event, note) => {
  console.log('Velocity bar mousedown:', note.id)
  isClickPending.value = true
  handleMouseDown(event, note)
}

const handleVelocityBarClick = (event, note) => {
  if (!isClickPending.value || isDragging.value) return
  
  console.log('Velocity bar click:', note.id)
  const newMidiVelocity = calculateVelocityFromPosition(event.clientY)
  updateNoteVelocity(note.id, newMidiVelocity)
  
  isClickPending.value = false
}

// Watch pour débugger les changements de sélection
watch(selectedItems, (newSelection) => {
  console.log('selectedItems changed:', newSelection)
}, { deep: true })

watch(previewSelectedItems, (newPreview) => {
  console.log('previewSelectedItems changed:', newPreview)
}, { deep: true })

// Lifecycle
let resizeObserver = null

onMounted(() => {
  if (velocityLaneRef.value) {
    laneHeightPx.value = velocityLaneRef.value.clientHeight || 100
    resizeObserver = new window.ResizeObserver(entries => {
      for (const entry of entries) {
        if (entry.target === velocityLaneRef.value) {
          laneHeightPx.value = entry.contentRect.height || 100
        }
      }
    })
    resizeObserver.observe(velocityLaneRef.value)
  }
})

onUnmounted(() => {
  if (resizeObserver && velocityLaneRef.value) {
    resizeObserver.unobserve(velocityLaneRef.value)
  }
  
  if (uiStore.hideVelocityDisplay) {
    uiStore.hideVelocityDisplay()
  }
  
  // CORRECTION: Nettoyer le cache de mise à jour
  updateCache.clear()
  if (updateBatchTimeout) {
    clearTimeout(updateBatchTimeout)
  }
})
</script>

<style scoped>
.velocity-lane {
  position: relative;
  height: 100%;
  background: var(--velocity-lane-bg, #fafafa);
  overflow: hidden;
  user-select: none;
  cursor: default;
}

.velocity-lane.brush-mode {
  cursor: crosshair;
}

.measures-grid {
  position: relative;
  height: 100%;
  min-height: 100px;
}

/* Responsive */
@media (max-width: 768px) {
  .velocity-lane {
    min-height: 80px;
  }
}

/* Mode sombre */
@media (prefers-color-scheme: dark) {
  .velocity-lane {
    --velocity-lane-bg: #1e1e1e;
  }
}
</style>
<template>
  <div class="tool-bar">
    <div class="tool-group">
      <el-button-group>
        <el-button :icon="VideoPlay" size="small">Play</el-button>
        <el-button :icon="VideoPause" size="small">Pause</el-button>
        <el-button :icon="RefreshLeft" size="small">Stop</el-button>
      </el-button-group>
    </div>

    <div class="tool-group">
      <span class="tool-label">Tempo:</span>
      <el-input-number v-model="tempo" :min="60" :max="200" size="small" style="width: 80px" />
      <span class="tool-label">BPM</span>
    </div>

    <div class="tool-group">
      <span class="tool-label">Signature:</span>
      <el-select v-model="timeSignature" size="small" style="width: 80px">
        <el-option label="4/4" value="4/4" />
        <el-option label="3/4" value="3/4" />
        <el-option label="2/4" value="2/4" />
        <el-option label="6/8" value="6/8" />
      </el-select>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useUIStore } from '@/stores/ui'
import { VideoPlay, VideoPause, RefreshLeft, ZoomIn, ZoomOut } from '@element-plus/icons-vue'

const uiStore = useUIStore()

const tempo = ref(120)
const timeSignature = ref('4/4')
</script>

<style scoped>
.tool-bar {
  height: 50px;
  display: flex;
  align-items: center;
  padding: 0 16px;
  border-bottom: 1px solid var(--border-color);
  background: var(--panel-bg);
  gap: 16px;
}

.tool-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.tool-label {
  font-size: 12px;
  color: var(--track-details);
  white-space: nowrap;
}
</style>
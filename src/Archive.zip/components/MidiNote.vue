<template>
  <div
    class="midi-note"
    :class="{
      selected: isSelected,
      dragging: isDragging,
      resizing: isResizing
    }"
    :style="noteStyle"
    @mousedown="onMouseDown"
    @mousemove="onMouseMove"
    @mouseleave="onMouseLeave"
    ref="noteRef"
  >
    <!-- Contenu de la note -->
    <div class="note-content">
      <span class="note-name">{{ noteName }}</span>
    </div>

    <!-- Handle de redimensionnement - toujours visible -->
    <div
      class="resize-handle"
      :class="{ 'resize-hover': showResizeCursor }"
      @mousedown.stop="startResize"
    ></div>

    <!-- Indicateur de snap -->
    <div v-if="showSnapIndicator" class="snap-indicator" :style="snapIndicatorStyle"></div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useUIStore } from '@/stores/ui'
import { useMidiStore } from '@/stores/midi'
import { usePianoPositioning } from '@/composables/usePianoPositioning'
import { useTimeSignature } from '@/composables/useTimeSignature'

const props = defineProps({
  note: Object
})

const uiStore = useUIStore()
const midiStore = useMidiStore()

// Utiliser les composables pour le positionnement et la temporalité
const {
  getMidiNotePosition,
  getNoteHeight,
  yToMidiNote,
  getNoteName,
  noteLineHeight
} = usePianoPositioning()

// Utiliser le composable pour les signatures rythmiques
const {
  timeToPixelsWithSignatures,
  pixelsToTimeWithSignatures,
  durationToPixels,
  pixelsToDuration,
  measuresWithSignatures,
  PIXELS_PER_QUARTER
} = useTimeSignature()

const noteRef = ref(null)
const isDragging = ref(false)
const isResizing = ref(false)
const showSnapIndicator = ref(false)
const showResizeCursor = ref(false)
const snapIndicatorStyle = ref({})

// Variables pour le dragging
let dragStartX = 0
let dragStartY = 0
let initialTime = 0
let initialMidi = 0
let initialDuration = 0
let resizeStartPixel = 0

const isSelected = computed(() => {
  return midiStore.selectedNote === props.note.id
})

const noteName = computed(() => {
  return props.note.name || getNoteName(props.note.midi)
})

// Fonction pour obtenir la couleur basée sur la vélocité
const getVelocityColor = (velocity) => {
  const normalizedVelocity = Math.max(0, Math.min(1, velocity))
  const hue = (1 - normalizedVelocity) * 120
  const saturation = 70
  const lightness = 50 + (normalizedVelocity * 20)
  return `hsl(${hue}, ${saturation}%, ${lightness}%)`
}

const noteStyle = computed(() => {
  // Position verticale (inchangée)
  const baseNoteY = getMidiNotePosition(props.note.midi)
  const baseNoteHeight = getNoteHeight()
  const noteHeight = baseNoteHeight * 1.35
  
  const heightDifference = noteHeight - baseNoteHeight
  const noteY = baseNoteY - (heightDifference / 2)

  // Gérer les deux formats possibles
  const noteStartTime = props.note.start || props.note.time

  // Position horizontale (inchangée)
  const leftPixels = timeToPixelsWithSignatures(noteStartTime)
  
  // ✅ CORRECTION PRINCIPALE: Nettoyer la durée des erreurs de virgule flottante
  const cleanDuration = Math.round(props.note.duration * 1000000) / 1000000
  
  // Calcul direct et précis
  const tempo = midiStore.getCurrentTempo || 120
  const quarterNotesCount = cleanDuration / (60 / tempo)
  const exactPixels = quarterNotesCount * PIXELS_PER_QUARTER.value
  const widthPixels = Math.round(exactPixels * 100) / 100

  // Debug pour voir la différence
  /*
  console.log(`Note ${props.note.name || 'Unknown'}:`)
  console.log(`  Durée brute: ${props.note.duration}s`)
  console.log(`  Durée nettoyée: ${cleanDuration}s`)
  console.log(`  Noires: ${quarterNotesCount}`)
  console.log(`  Pixels exacts: ${exactPixels}`)
  console.log(`  Pixels finaux: ${widthPixels}px`)
  */
 
  // Largeur minimale
  const minWidthPixels = Math.max(PIXELS_PER_QUARTER.value * 0.1, 8)

  return {
    left: leftPixels + 'px',
    top: noteY + 'px',
    width: Math.max(widthPixels, minWidthPixels) + 'px',
    height: noteHeight + 'px',
    backgroundColor: getVelocityColor(props.note.velocity),
    zIndex: isSelected.value ? 100 : 10
  }
})

const onMouseMove = (e) => {
  if (isDragging.value || isResizing.value) return

  const rect = noteRef.value.getBoundingClientRect()
  const x = e.clientX - rect.left
  const resizeZoneWidth = Math.max(PIXELS_PER_QUARTER.value * 0.2, 6)

  showResizeCursor.value = x >= rect.width - resizeZoneWidth
}

const onMouseLeave = () => {
  if (!isDragging.value && !isResizing.value) {
    showResizeCursor.value = false
  }
}

const onMouseDown = (e) => {
  e.preventDefault()
  e.stopPropagation()

  // Vérifier si on est sur la zone de redimensionnement
  const rect = noteRef.value.getBoundingClientRect()
  const x = e.clientX - rect.left
  const resizeZoneWidth = Math.max(PIXELS_PER_QUARTER.value * 0.2, 6)

  if (x >= rect.width - resizeZoneWidth) {
    startResize(e)
    return
  }

  // Sélectionner la note
  midiStore.selectNote(props.note.id)

  // Commencer le drag
  startDrag(e)
}

const startDrag = (e) => {
  isDragging.value = true
  dragStartX = e.clientX
  dragStartY = e.clientY
  initialTime = props.note.start || props.note.time
  initialMidi = props.note.midi

  document.addEventListener('mousemove', onDrag)
  document.addEventListener('mouseup', stopDrag)
  document.body.style.cursor = 'grabbing'
  document.body.style.userSelect = 'none'
}

const onDrag = (e) => {
  if (!isDragging.value) return

  const deltaX = e.clientX - dragStartX
  const deltaY = e.clientY - dragStartY

  // UTILISER LA MÊME LOGIQUE DE CONVERSION
  const currentNotePixel = timeToPixelsWithSignatures(initialTime)
  const newPixel = currentNotePixel + deltaX
  let newTime = pixelsToTimeWithSignatures(Math.max(0, newPixel))

  // Calcul de la nouvelle note MIDI
  const deltaMidi = Math.round(-deltaY / (noteLineHeight.value * uiStore.verticalZoom))
  let newMidi = initialMidi + deltaMidi

  // Contraintes
  newTime = Math.max(0, newTime)
  newMidi = Math.max(0, Math.min(127, newMidi))

  // Optionnel: Snap à la grille rythmique
  if (uiStore.snapToGrid) {
    newTime = snapToGridTime(newTime)
  }

  // Mettre à jour la position en temps réel
  updateNoteData({
    ...(props.note.start !== undefined ? { start: newTime } : { time: newTime }),
    midi: newMidi
  })
}

const stopDrag = () => {
  if (!isDragging.value) return

  isDragging.value = false
  showSnapIndicator.value = false

  document.removeEventListener('mousemove', onDrag)
  document.removeEventListener('mouseup', stopDrag)
  document.body.style.cursor = ''
  document.body.style.userSelect = ''
}

const startResize = (e) => {
  e.preventDefault()
  e.stopPropagation()

  isResizing.value = true
  dragStartX = e.clientX
  initialTime = props.note.start || props.note.time
  initialDuration = props.note.duration
  
  // UTILISER LA MÊME LOGIQUE DE CONVERSION
  resizeStartPixel = timeToPixelsWithSignatures(initialTime + initialDuration)

  document.addEventListener('mousemove', onResize)
  document.addEventListener('mouseup', stopResize)
  document.body.style.cursor = 'ew-resize'
  document.body.style.userSelect = 'none'
}

const onResize = (e) => {
  if (!isResizing.value) return

  const deltaX = e.clientX - dragStartX
  
  // Calculer la nouvelle position de fin en pixels
  const currentEndPixel = timeToPixelsWithSignatures(initialTime + initialDuration)
  const newEndPixel = Math.max(
    timeToPixelsWithSignatures(initialTime) + 8, // Largeur minimale
    currentEndPixel + deltaX
  )
  
  // Convertir en temps
  const newEndTime = pixelsToTimeWithSignatures(newEndPixel)
  let newDuration = newEndTime - initialTime
  
  // Contrainte minimale basée sur la grille rythmique
  const minDurationTime = getMinNoteDuration()
  newDuration = Math.max(minDurationTime, newDuration)

  // Optionnel: Snap de la fin de note à la grille
  if (uiStore.snapToGrid) {
    const snappedEndTime = snapToGridTime(initialTime + newDuration)
    newDuration = Math.max(minDurationTime, snappedEndTime - initialTime)
  }

  // Mettre à jour la durée en temps réel
  updateNoteData({ duration: newDuration })
}

const stopResize = () => {
  if (!isResizing.value) return

  isResizing.value = false
  showSnapIndicator.value = false
  showResizeCursor.value = false

  document.removeEventListener('mousemove', onResize)
  document.removeEventListener('mouseup', stopResize)
  document.body.style.cursor = ''
  document.body.style.userSelect = ''
}

// Fonction pour obtenir la durée minimale d'une note
const getMinNoteDuration = () => {
  const measures = measuresWithSignatures.value
  let currentMeasure = null
  
  for (const measure of measures) {
    if (initialTime >= measure.startTime && initialTime < measure.endTime) {
      currentMeasure = measure
      break
    }
  }
  
  if (currentMeasure) {
    const measureDuration = currentMeasure.endTime - currentMeasure.startTime
    const beatDuration = measureDuration / currentMeasure.beatsCount
    // Subdivision minimale : 32e de note
    return beatDuration / 32
  }
  
  // Fallback : 32e de note à 120 BPM
  return (60 / 120) / 32
}

// Fonction pour snapper à la grille rythmique
const snapToGridTime = (time) => {
  const measures = measuresWithSignatures.value
  let targetMeasure = null
  
  for (const measure of measures) {
    if (time >= measure.startTime && time < measure.endTime) {
      targetMeasure = measure
      break
    }
  }
  
  if (!targetMeasure) {
    targetMeasure = measures[measures.length - 1]
    if (!targetMeasure) return time
  }
  
  const timeInMeasure = time - targetMeasure.startTime
  const measureDuration = targetMeasure.endTime - targetMeasure.startTime
  const beatDuration = measureDuration / targetMeasure.beatsCount
  
  const subdivision = beatDuration / (uiStore.snapDivision || 4)
  const subdivisionIndex = Math.round(timeInMeasure / subdivision)
  const snappedTime = targetMeasure.startTime + (subdivisionIndex * subdivision)
  
  return Math.min(snappedTime, targetMeasure.endTime - getMinNoteDuration())
}

// Fonction pour mettre à jour les données de la note
const updateNoteData = (updates) => {
  const noteInStore = midiStore.notes.find(n => n.id === props.note.id)
  if (noteInStore) {
    Object.assign(noteInStore, updates)
  }
}

// Cleanup au démontage
import { onUnmounted } from 'vue'
onUnmounted(() => {
  document.removeEventListener('mousemove', onDrag)
  document.removeEventListener('mouseup', stopDrag)
  document.removeEventListener('mousemove', onResize)
  document.removeEventListener('mouseup', stopResize)
})
</script>

<style scoped>
.midi-note {
  position: absolute;
  border: 1px solid rgba(0,0,0,0.2);
  border-radius: 3px;
  cursor: grab;
  transition: box-shadow 0.2s;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 2px 4px;
  box-sizing: border-box;
  min-width: 8px;
}

.midi-note:hover {
  filter: brightness(1.1);
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.midi-note.selected {
  border-color: #2196F3;
  box-shadow: 0 0 8px rgba(33, 150, 243, 0.6);
  filter: brightness(1.2);
}

.midi-note.dragging {
  cursor: grabbing;
  z-index: 1000 !important;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

.midi-note.resizing {
  cursor: ew-resize;
}

.note-content {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  pointer-events: none;
}

.note-name {
  font-size: 11px;
  font-weight: bold;
  color: white;
  text-shadow: 0 1px 2px rgba(0,0,0,0.5);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.resize-handle {
  position: absolute;
  right: 0;
  top: 0;
  bottom: 0;
  width: 8px;
  background: rgba(255,255,255,0.2);
  cursor: ew-resize;
  border-radius: 0 2px 2px 0;
  transition: background-color 0.2s, width 0.2s;
}

.resize-handle.resize-hover,
.resize-handle:hover {
  background: rgba(255,255,255,0.4);
  width: 10px;
}

.midi-note.selected .resize-handle {
  background: rgba(255,255,255,0.3);
}

.snap-indicator {
  position: absolute;
  border: 2px dashed #FF9800;
  background: rgba(255, 152, 0, 0.1);
  pointer-events: none;
  border-radius: 3px;
  z-index: 999;
}
</style>
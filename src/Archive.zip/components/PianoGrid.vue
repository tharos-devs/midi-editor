<template>
  <div class="piano-grid" :style="gridStyle">
    <!-- Couche de fond avec les lignes - en position absolue pour dépasser les limites -->
    <div class="grid-background-fixed" :style="gridBackgroundStyle">
      <!-- Lignes horizontales pour TOUTES les notes MIDI (une ligne par note) -->
      <div
        v-for="note in allMidiNotes"
        :key="note.midi"
        class="note-line"
        :class="{
          'white-note-line': !note.isBlack,
          'black-note-line': note.isBlack
        }"
        :style="{
          top: getNoteLinePosition(note.midi) + 'px',
          height: noteLineHeight + 'px',
          width: totalWidth + 'px',
          left: '0px'
        }"
        :title="note.name"
      ></div>

      <!-- Lignes verticales (mesures) - TOUJOURS affichées -->
      <div
        v-for="measure in measures"
        :key="`measure-${measure.number}`"
        class="measure-line"
        :class="{ 'signature-change': measure.signatureChange }"
        :style="{
          left: measure.startPixel + 'px',
          height: calculatedPianoHeight + 'px',
          top: '0px'
        }"
        :title="measure.signatureChange ? `Mesure ${measure.number} - ${measure.timeSignature.numerator}/${measure.timeSignature.denominator}` : `Mesure ${measure.number}`"
      ></div>

      <!-- Lignes verticales (temps/beats) avec signatures rythmiques dynamiques -->
      <template v-for="measure in measures" :key="`beats-container-${measure.number}`">
        <div
          v-for="beatIndex in (measure.beatsCount - 1)"
          :key="`beat-${measure.number}-${beatIndex + 1}`"
          class="beat-line"
          :style="{
            left: (measure.startPixel + beatIndex * measure.beatWidth) + 'px',
            height: calculatedPianoHeight + 'px',
            top: '0px'
          }"
          :title="`Mesure ${measure.number}, Temps ${beatIndex + 1}`"
        ></div>
      </template>

      <!-- Debug: Afficher les données des mesures -->
      <div v-if="showDebug" class="debug-info" style="position: absolute; top: 10px; left: 10px; background: rgba(0,0,0,0.8); color: white; padding: 10px; z-index: 1000;">
        <div>Nombre de mesures: {{ measures.length }}</div>
        <div v-for="measure in measures.slice(0, 3)" :key="`debug-${measure.number}`">
          Mesure {{ measure.number }}: beats={{ measure.beatsCount }}, beatWidth={{ measure.beatWidth }}, startPixel={{ measure.startPixel }}
        </div>
      </div>
    </div>

    <!-- Notes MIDI utilisant le nouveau composant -->
    <div class="notes-layer">
      <MidiNote
        v-for="note in selectedTrackNotes"
        :key="note.id"
        :note="note"
      />
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useUIStore } from '@/stores/ui'
import { useMidiStore } from '@/stores/midi'
import { useTimeSignature } from '@/composables/useTimeSignature'
import { usePianoPositioning } from '@/composables/usePianoPositioning'
import MidiNote from '@/components/MidiNote.vue'

const midiStore = useMidiStore()
const uiStore = useUIStore()

// Debug flag - activez temporairement pour voir les données
const showDebug = ref(false) // Changez à true pour activer le debug

// Utiliser le composable centralisé pour les signatures rythmiques
const timeSignatureComposable = useTimeSignature()

// Utiliser le nouveau composable pour le positionnement du piano
const {
  allMidiNotes,
  noteLineHeight,
  calculatedPianoHeight,
  getNoteLinePosition
} = usePianoPositioning()

// Utiliser les mesures avec signatures rythmiques au lieu des lignes fixes
const measures = computed(() => {
  const result = timeSignatureComposable?.measuresWithSignatures?.value || []
  // console.log('Measures data:', result) // Debug log
  return result
})

const totalWidth = computed(() => {
  return timeSignatureComposable?.totalWidth?.value || 800
})

// ADAPTATION AU NOUVEAU STORE MIDI
// Remplacer getSelectedTrackNotes par une computed qui utilise les nouvelles getters
const selectedTrackNotes = computed(() => {
  // Si aucune piste sélectionnée, retourner un tableau vide
  if (midiStore.selectedTrack === null) {
    return []
  }
  
  // Utiliser la nouvelle getter getTrackNotes du store
  return midiStore.getTrackNotes(midiStore.selectedTrack)
})

const gridStyle = computed(() => ({
  width: totalWidth.value + 'px',
  height: calculatedPianoHeight.value + 'px'
}))

const gridBackgroundStyle = computed(() => ({
  width: totalWidth.value + 'px',
  height: calculatedPianoHeight.value + 'px'
}))
</script>

<style scoped>
.piano-grid {
  position: relative;
  background: var(--panel-bg);
}

.grid-background-fixed {
  position: absolute;
  top: 0;
  left: 0;
  pointer-events: none;
  z-index: 1;
}

.note-line {
  position: absolute;
  pointer-events: none;
  box-sizing: border-box;
  border-top: 1px solid var(--piano-beat-line);
  border-bottom: 1px solid var(--piano-beat-line);
}

/* Les couleurs des touches du piano ne sont pas modifiées */
.white-note-line {
  background: var(--piano-white-key-bg, rgba(255, 255, 255, 0.9));
}

.black-note-line {
  background: var(--piano-black-key-bg, rgba(240, 240, 240, 0.9));
}

.measure-line {
  position: absolute;
  top: 0;
  border-left: 2px solid var(--timeline-measure, #666);
  pointer-events: none;
  z-index: 2;
}

.measure-line.signature-change {
  border-left: 3px solid var(--timeline-signature, #d63384);
  box-shadow: 2px 0 4px var(--timeline-signature-shadow, rgba(214, 51, 132, 0.3));
}

.beat-line {
  position: absolute;
  top: 0;
  border-left: 1px solid var(--piano-beat-line, #ccc);
  pointer-events: none;
  z-index: 2;
}

.notes-layer {
  position: relative;
  width: 100%;
  height: 100%;
  z-index: 10;
}

.debug-info {
  font-family: monospace;
  font-size: 12px;
  max-width: 400px;
  border-radius: 4px;
}
</style>